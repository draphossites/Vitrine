# Vitrine na Vercel

A Vitrine é um app Next.js para criar catálogos online e receber pedidos pelo WhatsApp. O banco de produção começa vazio. A loja de exemplo **Turbo Games** já vem no código, em `/loja/turbo-demo`. As contas, lojas, imagens enviadas e credenciais do Sites ficam na instalação original.

## 1. Envie a pasta ao GitHub e importe na Vercel

1. Descompacte `Vitrine-GitHub-Vercel.zip`. No repositório `draphossites/Vitrine`, abra **Add file → Upload files**, arraste a pasta **`vercel` inteira** para a raiz do repositório e clique em **Commit changes**. Confira se o GitHub mostra `vercel/package.json` e `vercel/vercel.json`. [Guia de upload do GitHub](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)
2. Na Vercel, escolha **Add New → Project** e importe `draphossites/Vitrine`. Antes de clicar em **Deploy**, abra **Root Directory → Edit**, selecione **`vercel`** e confirme **Next.js** em **Framework Preset**. [Guia da Vercel](https://vercel.com/docs/monorepos)
3. Aguarde o status **Ready**. O endereço de produção mostra a página de configuração e o catálogo de demonstração em `/loja/turbo-demo`. Siga os próximos passos para ativar o cadastro, o Adimin e o envio de fotos.

O GitHub Pages publica páginas estáticas. O acesso com e-mail e senha e o banco da Vitrine usam o endereço de produção da Vercel. [Sobre o GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages)

## 2. Conecte o banco Turso

No projeto da Vercel, abra **Storage → Create Database → Turso**. Crie ou conecte um banco ao ambiente **Production**. A integração adiciona `TURSO_DATABASE_URL` e `TURSO_AUTH_TOKEN` ao projeto. [Turso no Vercel Marketplace](https://vercel.com/marketplace/tursocloud/database)

Se preferir configurar o banco manualmente, crie um banco **libSQL** no Turso, copie a URL de conexão e gere um token com acesso de escrita. Você também pode obter esses valores com a CLI do Turso. Substitua `vitrine` pelo nome do banco que você escolher. [Painel do Turso](https://app.turso.tech/), [guia da CLI](https://docs.turso.tech/quickstart)

```bash
turso auth login
turso db create vitrine
turso db show --url vitrine
turso db tokens create vitrine
```

No projeto da Vercel, abra **Settings → Environment Variables**. Na configuração manual, adicione `TURSO_DATABASE_URL` com a URL do banco e `TURSO_AUTH_TOKEN` com o token. Selecione **Production** e salve o token como **Secret**. [Configurações do projeto](https://vercel.com/docs/project-configuration/project-settings), [como adicionar variáveis de ambiente](https://vercel.com/docs/environment-variables/managing-environment-variables)

## 3. Configure o acesso do Adimin

Instale o Node.js **24.x**, extraia uma cópia do ZIP no computador e abra um terminal na pasta que contém `package.json`. Execute o comando abaixo. [Download do Node.js](https://nodejs.org/en/download)

```bash
node scripts/configurar-adimin.mjs
```

Digite o e-mail e escolha a senha que você vai usar em `/admin`. A senha fica oculta enquanto você digita. O comando grava em `.env.local` o e-mail, um verificador da senha e uma chave de sessão. Guarde a senha para entrar no painel e mantenha o arquivo `.env.local` no seu computador.

Abra `.env.local` em um editor. Em **Settings → Environment Variables** do projeto na Vercel, adicione as três variáveis abaixo como **Secret** em **Production**. Para cada variável, copie o trecho depois do `=`. [Variáveis Secret na Vercel](https://vercel.com/docs/environment-variables/sensitive-environment-variables)

| Nome | Valor |
| --- | --- |
| `VITRINE_MASTER_LOGIN_EMAIL` | E-mail gravado em `.env.local` |
| `VITRINE_MASTER_PASSWORD_VERIFIER` | Valor que começa com `v1:` |
| `VITRINE_MASTER_SESSION_KEY` | Chave de sessão gravada em `.env.local` |

## 4. Ative o envio de imagens

No projeto da Vercel, abra **Storage → Create Database → Blob**. Escolha **Public** como tipo de acesso e conecte o armazenamento ao ambiente **Production**. A integração atual usa OIDC para autenticar os uploads automaticamente. Em uma conexão legada, a Vercel fornece `BLOB_READ_WRITE_TOKEN`. [Como criar um Blob público](https://vercel.com/docs/vercel-blob/public-storage), [autenticação OIDC do Vercel Blob](https://vercel.com/changelog/vercel-blob-now-supports-oidc-authentication)

## 5. Aplique as configurações com Redeploy

No mesmo projeto, abra **Deployments**, procure a publicação mais recente de **Production** e clique em **⋯ → Redeploy**. Confirme e aguarde até aparecer **Ready**. É nesse novo deploy que as variáveis e a conexão com o Blob entram em vigor. Com o Turso configurado, o build cria as tabelas do banco e, nos próximos deploys, aplica as migrações pendentes. [Como refazer um deploy](https://vercel.com/docs/deployments/managing-deployments#redeploy-a-project)

## 6. Confira o site publicado

Abra o domínio de produção exibido pela Vercel. Acrescente cada caminho abaixo ao endereço.

| Caminho | O que você pode fazer |
| --- | --- |
| `/` | Abrir a página inicial |
| `/loja/turbo-demo` | Ver um catálogo pronto com os dados de demonstração |
| `/cadastro` | Criar uma conta de lojista e uma loja |
| `/entrar` | Entrar como lojista |
| `/lojista` | Configurar a loja, adicionar produtos e enviar uma foto |
| `/admin` | Entrar no Adimin com o e-mail e a senha definidos no passo 3 |

Compartilhe o endereço `/loja/<slug-da-loja>` que aparece no painel do lojista para que os clientes vejam o seu catálogo.

## Rodar no computador

Na pasta extraída, com Node.js 24.x, execute estes comandos. Gere o acesso do Adimin conforme o passo 3 se quiser testar esse painel.

```bash
npm ci
npm run db:migrate
npm run dev
```

Abra [http://localhost:3000](http://localhost:3000). Em desenvolvimento, a configuração padrão usa SQLite e imagens locais em `.vitrine-data/`. Se quiser usar um banco Turso de desenvolvimento, adicione as duas variáveis do Turso em `.env.local` e rode `npm run db:migrate` novamente. Para testar imagens com um Blob público fora da Vercel, você pode adicionar `BLOB_READ_WRITE_TOKEN` do armazenamento ao mesmo arquivo. [.env.example](.env.example)
