import { mkdirSync } from "node:fs";
import { createClient } from "@libsql/client";

export const localDataDirectory = ".vitrine-data";

export function isVercel() {
  return Boolean(process.env.VERCEL || process.env.VERCEL_ENV);
}

export function createVitrineClient() {
  const url = process.env.TURSO_DATABASE_URL?.trim();
  const authToken = process.env.TURSO_AUTH_TOKEN?.trim();

  if (!isVercel() && !url && !authToken) {
    mkdirSync(localDataDirectory, { recursive: true });
    return createClient({ url: `file:${localDataDirectory}/vitrine.sqlite`, timeout: 5000 });
  }

  if (!url || !authToken) {
    throw new Error("Configure TURSO_DATABASE_URL e TURSO_AUTH_TOKEN para conectar a Vitrine ao Turso.");
  }
  if (!/^(libsql|https):\/\//i.test(url)) {
    throw new Error("TURSO_DATABASE_URL deve usar um endereço libsql:// ou https:// do Turso.");
  }

  return createClient({ url, authToken });
}

function queryResult({ rows, rowsAffected }) {
  return { results: rows.map((row) => ({ ...row })), meta: { changes: rowsAffected } };
}

export function vitrineDatabase(client) {
  function statement(sql, args = []) {
    const query = { sql, args };
    const execute = async () => queryResult(await client.execute(query));
    return {
      query,
      bind: (...params) => statement(sql, params),
      first: async () => (await execute()).results[0] ?? null,
      all: execute,
      run: execute,
    };
  }

  return {
    prepare: statement,
    async batch(statements) {
      const results = await client.batch(statements.map(({ query }) => query));
      return results.map(queryResult);
    },
  };
}
