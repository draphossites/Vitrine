import { headers } from "next/headers";
import { readMerchantSession } from "../../server/merchant-auth.mjs";
import { usesLocalCookies } from "../../server/request-auth.mjs";
import { getVitrineEnv } from "../../server/runtime.mjs";
import { Dashboard } from "../ui/Dashboard.jsx";
export const dynamic = "force-dynamic";
export const metadata = { title: "Painel do lojista | Vitrine" };
export default async function MerchantPage({ searchParams }: { searchParams: Promise<{ aba?: string }> }) {
  const [requestHeaders, query] = await Promise.all([headers(), searchParams]);
  const session = await readMerchantSession(getVitrineEnv().DB, requestHeaders.get("cookie"), usesLocalCookies(requestHeaders));
  return <Dashboard mode="merchant" authenticated={Boolean(session)} initialTab={query?.aba === "acesso" ? "account" : "overview"}/>;
}
