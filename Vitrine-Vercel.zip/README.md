# Vitrine na Vercel

A Vitrine é um app Next.js para criar catálogos online e receber pedidos pelo WhatsApp. O banco de produção começa vazio. A loja de exemplo **Turbo Games** já vem no código, em `/loja/turbo-demo`. As contas, lojas, imagens enviadas e credenciais do Sites ficam na instalação original.

## 1. Envie os arquivos para o GitHub

1. Extraia o ZIP e abra a pasta que contém `package.json`.
2. No GitHub, crie um repositório. Abra **Add file → Upload files** e arraste para a página todos os arquivos e pastas que vieram no ZIP, incluindo `.gitignore` e `.env.example`. Mantenha `package.json` na primeira tela do repositório, junto com `vercel.json` e as pastas `app`, `server` e `drizzle`.
3. Clique em **Commit changes** para salvar o código. Mantenha `.env.local` e quaisquer credenciais fora do repositório. [Como enviar arquivos pelo GitHub](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)

## 2. Gere o acesso do Adimin

Instale o Node.js **24.x**. Abra um terminal na pasta extraída, onde está o `package.json`, e execute este comando. [Download do Node.js](https://nodejs.org/en/download)

```bash
node scripts/configurar-adimin.mjs
```

Digite o e-mail do administrador e a senha que você quer usar em `/admin`. O terminal oculta a digitação da senha. O comando grava em `.env.local` o e-mail, um verificador da senha e uma chave aleatória de sessão. Guarde a senha que você escolheu para entrar no painel.

Abra `.env.local` em um editor para copiar os trechos depois do `=` quando configurar o projeto na Vercel. Se você executar o comando novamente, ele pede confirmação antes de trocar o acesso e a chave. Uma chave nova encerra as sessões do Adimin após o deploy com essa chave.

## 3. Prepare o banco no Turso

Para o primeiro deploy, crie um banco **libSQL** no painel do Turso. Abra o banco e obtenha a URL de conexão e um token do banco com acesso de escrita. [Painel do Turso](https://app.turso.tech/)

Se preferir usar a CLI do Turso, use estes comandos após instalá-la. Substitua `vitrine` pelo nome que você escolher e guarde os dois valores exibidos pelos últimos comandos. [Guia do Turso](https://docs.turso.tech/quickstart), [criação de token](https://docs.turso.tech/cli/db/tokens/create)

```bash
turso auth login
turso db create vitrine
turso db show --url vitrine
turso db tokens create vitrine
```

Se você já tem o projeto na Vercel, pode conectar um banco por **Storage → Create Database → Turso**. A integração adiciona `TURSO_DATABASE_URL` e `TURSO_AUTH_TOKEN` ao ambiente selecionado. Escolha **Production** para o site publicado. [Turso no Vercel Marketplace](https://vercel.com/marketplace/tursocloud/database)

## 4. Importe o projeto e faça o primeiro deploy

1. Na Vercel, escolha **Add New → Project** e importe o repositório do GitHub. Em **Framework Preset**, selecione **Next.js**. Em **Root Directory**, deixe a raiz do repositório, onde está o `package.json`. [Como importar um repositório na Vercel](https://vercel.com/docs/git)
2. Abra **Environment Variables**. Adicione os valores abaixo para **Production**. Se o Marketplace já adicionou as duas variáveis do Turso ao projeto, mantenha os valores da integração. Use o tipo **Secret** para os três valores do Adimin e para o token do Turso se você estiver inserindo-o manualmente. [Variáveis Secret na Vercel](https://vercel.com/docs/environment-variables/sensitive-environment-variables)

   | Nome | Valor |
   | --- | --- |
   | `TURSO_DATABASE_URL` | URL do banco libSQL |
   | `TURSO_AUTH_TOKEN` | Token de escrita do banco |
   | `VITRINE_MASTER_LOGIN_EMAIL` | E-mail gravado em `.env.local` |
   | `VITRINE_MASTER_PASSWORD_VERIFIER` | Valor que começa com `v1:` em `.env.local` |
   | `VITRINE_MASTER_SESSION_KEY` | Chave gravada em `.env.local` |

3. Clique em **Deploy**. O comando definido em `vercel.json` aplica as migrações com `npm run db:migrate` antes de compilar o Next.js. Ele cria as tabelas no primeiro deploy e aplica somente as migrações pendentes nos seguintes.

## 5. Ative o envio de imagens

1. No projeto da Vercel, abra **Storage → Create Database → Blob**. Escolha **Public** como tipo de acesso e conecte o armazenamento ao projeto no ambiente **Production**. A integração atual usa OIDC para autenticar os uploads automaticamente. Em uma conexão legada, a Vercel fornece `BLOB_READ_WRITE_TOKEN`. [Como criar um Blob público](https://vercel.com/docs/vercel-blob/public-storage), [autenticação OIDC do Vercel Blob](https://vercel.com/changelog/vercel-blob-now-supports-oidc-authentication)
2. Em **Deployments**, abra o menu da publicação mais recente e selecione **Redeploy** para usar o Blob conectado. Repita o deploy após mudanças nas variáveis de ambiente. [Como as variáveis são aplicadas aos deploys](https://vercel.com/docs/environment-variables)

## 6. Confira o site publicado

Abra o domínio de produção exibido pela Vercel. Acrescente cada caminho abaixo ao endereço.

| Caminho | O que você pode fazer |
| --- | --- |
| `/` | Abrir a página inicial |
| `/loja/turbo-demo` | Ver um catálogo pronto com os dados de demonstração |
| `/cadastro` | Criar uma conta de lojista e uma loja |
| `/entrar` | Entrar como lojista |
| `/lojista` | Configurar a loja, adicionar produtos e enviar uma foto |
| `/admin` | Entrar no Adimin com o e-mail e a senha definidos no passo 2 |

Compartilhe o endereço `/loja/<slug-da-loja>` que aparece no painel do lojista para que os clientes vejam o seu catálogo.

## Rodar no computador

Na pasta extraída, com Node.js 24.x, execute estes comandos. Gere o acesso do Adimin conforme o passo 2 se quiser testar esse painel.

```bash
npm ci
npm run db:migrate
npm run dev
```

Abra [http://localhost:3000](http://localhost:3000). Em desenvolvimento, a configuração padrão usa SQLite e imagens locais em `.vitrine-data/`. Se quiser usar um banco Turso de desenvolvimento, adicione as duas variáveis do Turso em `.env.local` e rode `npm run db:migrate` novamente. Para testar imagens com um Blob público fora da Vercel, você pode adicionar `BLOB_READ_WRITE_TOKEN` do armazenamento ao mesmo arquivo. [.env.example](.env.example)
