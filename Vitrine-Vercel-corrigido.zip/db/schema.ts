import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const users = sqliteTable("users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  createdAt: text("created_at").notNull(),
});

export const stores = sqliteTable("stores", {
  id: text("id").primaryKey(),
  ownerId: text("owner_id").notNull().unique().references(() => users.id),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  whatsapp: text("whatsapp").notNull(),
  logoUrl: text("logo_url").notNull().default(""),
  bannerUrl: text("banner_url").notNull().default(""),
  primaryColor: text("primary_color").notNull().default("#fb650d"),
  backgroundColor: text("background_color").notNull().default("#fbf7ef"),
  font: text("font").notNull().default("system"),
  deliveryEnabled: integer("delivery_enabled").notNull().default(0),
  deliveryFeeCents: integer("delivery_fee_cents").notNull().default(0),
  paymentMethods: text("payment_methods").notNull().default('["pix","card","cash"]'),
  status: text("status").notNull().default("active"),
  subscriptionStatus: text("subscription_status").notNull().default("pending"),
  subscriptionExpiresAt: text("subscription_expires_at"),
  createdAt: text("created_at").notNull(),
});

export const products = sqliteTable("products", {
  id: text("id").primaryKey(),
  storeId: text("store_id").notNull().references(() => stores.id),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  priceCents: integer("price_cents").notNull(),
  imageUrl: text("image_url").notNull().default(""),
  category: text("category").notNull().default(""),
  available: integer("available").notNull().default(1),
  createdAt: text("created_at").notNull(),
}, (table) => [index("products_store_idx").on(table.storeId, table.createdAt)]);

export const orders = sqliteTable("orders", {
  id: text("id").primaryKey(),
  storeId: text("store_id").notNull().references(() => stores.id),
  requestId: text("request_id").notNull(),
  customerName: text("customer_name").notNull(),
  fulfillment: text("fulfillment").notNull(),
  address: text("address").notNull(),
  paymentMethod: text("payment_method").notNull(),
  notes: text("notes").notNull(),
  items: text("items").notNull(),
  totalCents: integer("total_cents").notNull(),
  deliveryFeeCents: integer("delivery_fee_cents").notNull(),
  status: text("status").notNull().default("open"),
  createdAt: text("created_at").notNull(),
}, (table) => [
  uniqueIndex("orders_request_idx").on(table.storeId, table.requestId),
  index("orders_store_idx").on(table.storeId, table.createdAt),
]);

export const payments = sqliteTable("payments", {
  id: text("id").primaryKey(),
  storeId: text("store_id").notNull().references(() => stores.id),
  reference: text("reference").notNull(),
  receiptUrl: text("receipt_url").notNull().default(""),
  status: text("status").notNull().default("pending"),
  reviewKey: text("review_key"),
  createdAt: text("created_at").notNull(),
}, (table) => [
  index("payments_store_idx").on(table.storeId, table.createdAt),
]);

export const history = sqliteTable("history", {
  id: text("id").primaryKey(),
  actorName: text("actor_name").notNull(),
  description: text("description").notNull(),
  createdAt: text("created_at").notNull(),
}, (table) => [index("history_date_idx").on(table.createdAt)]);

export const merchantCredentials = sqliteTable("merchant_credentials", {
  userId: text("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  email: text("email").notNull().unique(),
  verifier: text("verifier").notNull(),
  createdAt: text("created_at").notNull(),
});

export const merchantSessions = sqliteTable("merchant_sessions", {
  tokenHash: text("token_hash").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: integer("expires_at").notNull(),
  createdAt: integer("created_at").notNull(),
}, (table) => [
  index("merchant_sessions_expires_idx").on(table.expiresAt),
  index("merchant_sessions_user_idx").on(table.userId),
]);

export const merchantLoginAttempts = sqliteTable("merchant_login_attempts", {
  key: text("key").primaryKey(),
  startsAt: integer("starts_at").notNull(),
  attempts: integer("attempts").notNull(),
}, (table) => [index("merchant_login_attempts_starts_idx").on(table.startsAt)]);
