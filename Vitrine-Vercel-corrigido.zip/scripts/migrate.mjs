import { createHash } from "node:crypto";
import { existsSync } from "node:fs";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { createVitrineClient, needsHostedDatabaseSetup } from "../server/database.mjs";

const envFile = fileURLToPath(new URL("../.env.local", import.meta.url));
if (existsSync(envFile)) process.loadEnvFile(envFile);

async function migrate() {
  const directory = new URL("../drizzle/", import.meta.url);
  const journal = JSON.parse(await readFile(new URL("meta/_journal.json", directory), "utf8"));
  const migrations = await Promise.all(journal.entries.map(async ({ tag }) => {
    const sql = (await readFile(new URL(`${tag}.sql`, directory), "utf8")).replace(/\r\n/g, "\n");
    return {
      tag,
      checksum: createHash("sha256").update(sql).digest("hex"),
      statements: sql.split("--> statement-breakpoint").map((part) => part.trim()).filter(Boolean),
    };
  }));

  const client = createVitrineClient();
  try {
    const transaction = await client.transaction("write");
    try {
      const [, ledger] = await transaction.batch([
        `CREATE TABLE IF NOT EXISTS vitrine_migrations (
          tag TEXT PRIMARY KEY NOT NULL,
          checksum TEXT NOT NULL,
          applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )`,
        "SELECT tag, checksum FROM vitrine_migrations",
      ]);
      const applied = new Map(ledger.rows.map(({ tag, checksum }) => [tag, checksum]));
      const pending = migrations.filter(({ tag, checksum }) => {
        const previous = applied.get(tag);
        if (previous && previous !== checksum) throw new Error(`A migração ${tag} foi alterada depois da aplicação.`);
        return !previous;
      });
      if (pending.length) {
        await transaction.batch(pending.flatMap(({ tag, checksum, statements }) => [
          ...statements,
          { sql: "INSERT INTO vitrine_migrations (tag, checksum) VALUES (?, ?)", args: [tag, checksum] },
        ]));
      }
      await transaction.commit();

      for (const { tag } of pending) console.log(`Migração aplicada: ${tag}`);
      if (!pending.length) console.log("Banco da Vitrine atualizado.");
    } catch (error) {
      await transaction.rollback();
      throw error;
    } finally {
      transaction.close();
    }
  } finally {
    client.close();
  }
}

if (process.argv.includes("--allow-unconfigured") && needsHostedDatabaseSetup()) {
  console.log("Migrações pendentes. Na Vercel, configure TURSO_DATABASE_URL e TURSO_AUTH_TOKEN em Settings → Environment Variables e faça um novo deploy.");
} else {
  await migrate();
}
