import { pbkdf2Sync, randomBytes } from "node:crypto";
import { open, readFile, rename, rm } from "node:fs/promises";
import { stdin, stdout } from "node:process";
import { createInterface } from "node:readline/promises";
import { Writable } from "node:stream";
import { parseEnv } from "node:util";

const localFile = new URL("../.env.local", import.meta.url);
const temporaryFile = new URL("../.env.local.adimin.tmp", import.meta.url);
const emailKey = "VITRINE_MASTER_LOGIN_EMAIL";
const passwordKey = "VITRINE_MASTER_PASSWORD_VERIFIER";
const sessionKey = "VITRINE_MASTER_SESSION_KEY";

async function readLocalFile() {
  try {
    return await readFile(localFile, "utf8");
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    return null;
  }
}

function updateVariables(original, variables) {
  const bom = original?.startsWith("\uFEFF") ? "\uFEFF" : "";
  const newline = original?.includes("\r\n") ? "\r\n" : "\n";
  // Match complete assignments, including quoted values that span lines.
  const assignment = /^[\t ]*(?:export[\t ]+)?([\w.-]+)[\t ]*=[\t ]*(?:"(?:\\[\s\S]|[^"\\])*"|'[^']*'|`[^`]*`|[^\r\n]*)[\t ]*(?:#[^\r\n]*)?(?:\r\n|\n|\r|$)/gm;
  const content = (original ?? "").slice(bom.length).replace(assignment, (entry, key) => {
    return variables.has(key) ? "" : entry;
  });
  const separator = content && !/[\r\n]$/.test(content) ? newline : "";
  const entries = [...variables].map(([key, value]) => `${key}=${value}`);
  return bom + content + separator + entries.join(newline) + newline;
}

async function saveLocalFile(original, variables) {
  const temporary = await open(temporaryFile, "wx", 0o600);
  try {
    try {
      await temporary.writeFile(updateVariables(original, variables), "utf8");
    } finally {
      await temporary.close();
    }
    if (await readLocalFile() !== original) {
      throw new Error("O arquivo .env.local foi alterado durante a configuração. Execute o comando novamente.");
    }
    await rename(temporaryFile, localFile);
  } finally {
    await rm(temporaryFile, { force: true });
  }
}

async function configureAdimin() {
  if (!stdin.isTTY || !stdout.isTTY) {
    throw new Error("Execute o comando em um terminal interativo.");
  }

  const original = await readLocalFile();
  const current = parseEnv((original ?? "").replace(/^\uFEFF/, ""));
  let hideInput = false;
  const output = new Writable({
    write(chunk, encoding, done) {
      if (hideInput) done();
      else stdout.write(chunk, encoding, done);
    },
  });
  const prompt = createInterface({ input: stdin, output, terminal: true });
  const abort = new AbortController();
  prompt.on("SIGINT", () => abort.abort());
  prompt.on("close", () => abort.abort());

  function ask(question) {
    return prompt.question(question, { signal: abort.signal });
  }

  async function askPassword(question) {
    stdout.write(question);
    hideInput = true;
    try {
      return await ask("");
    } finally {
      hideInput = false;
      stdout.write("\n");
    }
  }

  try {
    if ([emailKey, passwordKey, sessionKey].some((key) => current[key]?.trim())) {
      const answer = await ask("Já há uma configuração do Adimin. Trocar os dados de acesso e a chave de sessão? [s/N] ");
      if (!/^(s|sim)$/i.test(answer.trim())) {
        console.log("A configuração atual foi preservada.");
        return;
      }
    }

    const email = (await ask("E-mail do Adimin: ")).trim().toLowerCase();
    if (email.length > 254 || !/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z0-9-]+$/.test(email)) {
      throw new Error("Informe um e-mail válido.");
    }
    const password = await askPassword("Senha do Adimin (digitação oculta): ");
    if (!password || password.length > 256) {
      throw new Error("Use uma senha de 1 a 256 caracteres.");
    }
    const confirmation = await askPassword("Confirme a senha: ");
    if (confirmation !== password) throw new Error("As senhas são diferentes. Execute o comando novamente.");

    const salt = randomBytes(16);
    const hash = pbkdf2Sync(password, salt, 100000, 32, "sha256");
    await saveLocalFile(original, new Map([
      [emailKey, email],
      [passwordKey, `v1:${salt.toString("hex")}:${hash.toString("hex")}`],
      [sessionKey, randomBytes(32).toString("hex")],
    ]));
    console.log("Os dados de acesso do Adimin foram gravados em .env.local.");
  } finally {
    prompt.close();
  }
}

configureAdimin().catch((error) => {
  console.error(error.name === "AbortError" ? "Configuração cancelada." : error.message);
  process.exitCode = 1;
});
