export function AppMark() {
  return <a className="app-mark" href="/" aria-label="Página inicial da Vitrine"><Icon kind="store"/><span>vitrine<span>.</span></span></a>;
}

export function Icon({ kind, size = 21 }) {
  const paths = {
    store: <><path d="M3 9l2-5h14l2 5v2a2.5 2.5 0 0 1-4.5 1.5A2.6 2.6 0 0 1 12 12.5a2.6 2.6 0 0 1-4.5 0A2.5 2.5 0 0 1 3 11Z"/><path d="M5 13v7h14v-7M10 20v-4h4v4"/></>,
    box: <><path d="m3.5 7.5 8.5-4.7 8.5 4.7v9l-8.5 4.7-8.5-4.7z"/><path d="m3.5 7.5 8.5 4.7 8.5-4.7M12 12.2v9m-4-16 8 4.4"/></>,
    chat: <path d="M21 11.5a9 9 0 0 1-9 9 9.6 9.6 0 0 1-4.1-.9l-4.8 1.2 1.2-4.7a9.6 9.6 0 0 1-1-4.6 8.9 8.9 0 0 1 17.7 0Z"/>,
    sliders: <><path d="M4 6h16M4 12h16M4 18h16"/><circle fill="var(--paper)" cx="9" cy="6" r="2"/><circle fill="var(--paper)" cx="15" cy="12" r="2"/><circle fill="var(--paper)" cx="10" cy="18" r="2"/></>,
    exit: <><path d="M11 4H5v16h6m4-4 4-4-4-4m4 4H9"/></>,
    lock: <><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 4v2"/></>,
  };
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">{paths[kind] || paths.store}</svg>;
}
