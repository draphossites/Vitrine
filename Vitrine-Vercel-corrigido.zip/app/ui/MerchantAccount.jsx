"use client";

import { useState } from "react";
import { api } from "./api.js";
import { Icon } from "./Chrome.jsx";
import "./merchant-account.css";

function slugFromName(name) {
  return name.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase()
    .replace(/[^a-z0-9]+/g, "-").replace(/^-/, "").slice(0, 55).replace(/-$/, "");
}

function validateAccount(form, values, registering) {
  if (registering) {
    if (!values.name) return { field: "name", message: "Informe o nome da sua loja." };
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(values.slug) || values.slug.length < 3 || values.slug.length > 55) {
      return { field: "slug", message: "Use de 3 a 55 caracteres no endereço, com letras minúsculas, números e hífens entre eles." };
    }
    if (values.slug === "turbo-demo") {
      return { field: "slug", message: "O endereço da demonstração está reservado. Escolha outro endereço." };
    }
    if (!/^(?:55)?[1-9]\d{9,10}$/.test(values.whatsapp.replace(/\D/g, ""))) {
      return { field: "whatsapp", message: "Informe o WhatsApp com DDD e 10 ou 11 dígitos." };
    }
  }
  if (!values.email || form.elements.email.validity.typeMismatch) {
    return { field: "email", message: "Informe um e-mail válido." };
  }
  if (!values.password) return { field: "password", message: "Informe sua senha." };
  if (registering && (values.password.length < 8 || values.password.length > 256)) {
    return { field: "password", message: "Use uma senha de 8 a 256 caracteres." };
  }
  if (registering && values.password !== form.elements.confirmation.value) {
    return { field: "confirmation", message: "Digite a mesma senha nos dois campos." };
  }
  return null;
}

export default function MerchantAccount({ mode }) {
  const registering = mode === "register";
  const [name, setName] = useState("");
  const [customSlug, setCustomSlug] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const slug = customSlug ?? slugFromName(name);
  const pendingLabel = registering ? "Criando loja…" : "Entrando…";

  async function submitAccount(event) {
    event.preventDefault();
    if (submitting) return;

    const form = event.currentTarget;
    const fields = new FormData(form);
    const credentials = { email: fields.get("email").trim(), password: fields.get("password") };
    const values = registering ? {
      name: fields.get("name").trim(),
      slug: fields.get("slug").trim(),
      whatsapp: fields.get("whatsapp").trim(),
      ...credentials,
    } : credentials;
    const invalid = validateAccount(form, values, registering);

    if (invalid) {
      setError(invalid);
      form.elements.namedItem(invalid.field).focus();
      return;
    }

    setError(null);
    setSubmitting(true);
    try {
      await api(registering ? "account/register" : "account/login", { method: "POST", body: values });
      window.location.replace("/lojista");
    } catch (failure) {
      setError({ message: failure instanceof TypeError ? "Não foi possível conectar. Tente novamente." : failure.message });
      setSubmitting(false);
    }
  }

  function fieldAccessibility(field, hint) {
    const invalid = error?.field === field;
    return {
      "aria-invalid": invalid || undefined,
      "aria-describedby": [hint, invalid && "merchant-account-error"].filter(Boolean).join(" ") || undefined,
    };
  }

  return <main className={`merchant-account${registering ? "" : " merchant-account-narrow"}`} aria-labelledby="merchant-account-title">
    <span className="merchant-account-icon"><Icon kind={registering ? "store" : "lock"} size={26}/></span>
    <h1 id="merchant-account-title">{registering ? "Crie sua loja" : "Entre na sua loja"}</h1>
    <p className="merchant-account-description">{registering
      ? "Cadastre sua loja para montar o catálogo e receber pedidos pelo WhatsApp."
      : "Use seu e-mail e sua senha para acessar o painel do lojista."}</p>

    <form className="merchant-account-form" method="post" noValidate onSubmit={submitAccount} onChange={() => error && setError(null)} aria-busy={submitting}>
      <fieldset className="merchant-account-fields" disabled={submitting}>
        {registering && <>
          <div className="merchant-account-field merchant-account-full">
            <label htmlFor="merchant-account-name">Nome da loja</label>
            <input id="merchant-account-name" name="name" autoComplete="organization" required maxLength={100}
              value={name} onChange={(event) => setName(event.target.value)} {...fieldAccessibility("name")}/>
          </div>
          <div className="merchant-account-field merchant-account-full">
            <label htmlFor="merchant-account-slug">Endereço da loja</label>
            <div className="merchant-account-slug">
              <span aria-hidden="true">/loja/</span>
              <input id="merchant-account-slug" name="slug" autoComplete="off" autoCapitalize="none" spellCheck={false}
                placeholder="minha-loja" required minLength={3} maxLength={55} value={slug}
                onChange={(event) => setCustomSlug(event.target.value)} {...fieldAccessibility("slug", "merchant-account-slug-hint")}/>
            </div>
            <p className="merchant-account-hint" id="merchant-account-slug-hint">Use de 3 a 55 caracteres, com letras minúsculas, números e hífens.</p>
          </div>
          <div className="merchant-account-field">
            <label htmlFor="merchant-account-whatsapp">WhatsApp com DDD</label>
            <input id="merchant-account-whatsapp" name="whatsapp" type="tel" autoComplete="tel" placeholder="(11) 98765-4321"
              required maxLength={35} {...fieldAccessibility("whatsapp")}/>
          </div>
        </>}
        <div className="merchant-account-field">
          <label htmlFor="merchant-account-email">E-mail</label>
          <input id="merchant-account-email" name="email" type="email" autoComplete="username" autoCapitalize="none"
            spellCheck={false} required maxLength={254} {...fieldAccessibility("email")}/>
        </div>
        <div className="merchant-account-field">
          <label htmlFor="merchant-account-password">Senha</label>
          <input id="merchant-account-password" name="password" type="password" autoComplete={registering ? "new-password" : "current-password"}
            required minLength={registering ? 8 : undefined} maxLength={256}
            {...fieldAccessibility("password", registering ? "merchant-account-password-hint" : undefined)}/>
          {registering && <p className="merchant-account-hint" id="merchant-account-password-hint">De 8 a 256 caracteres.</p>}
        </div>
        {registering && <div className="merchant-account-field">
          <label htmlFor="merchant-account-confirmation">Confirmar senha</label>
          <input id="merchant-account-confirmation" name="confirmation" type="password" autoComplete="new-password"
            required minLength={8} maxLength={256} {...fieldAccessibility("confirmation")}/>
        </div>}
        {error && <div className="merchant-account-error merchant-account-full" id="merchant-account-error" role="alert">{error.message}</div>}
        <button type="submit" className="button button-primary merchant-account-action merchant-account-full" disabled={submitting}>
          {submitting ? pendingLabel : registering ? "Criar minha loja" : "Entrar"}
        </button>
      </fieldset>
    </form>
    <span className="merchant-account-status" role="status">{submitting ? pendingLabel : ""}</span>

    <p className="merchant-account-switch">{registering
      ? <>Já tem uma loja? <a href="/entrar">Entrar</a></>
      : <>Primeira vez na Vitrine? <a href="/cadastro">Criar minha loja</a></>}</p>
  </main>;
}
