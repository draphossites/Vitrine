'use client';

import React, { useEffect, useId, useMemo, useRef, useState } from 'react';
import './storefront.css';

const currency = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const maxQuantity = 20;
const maxProducts = 30;
const supportedFonts = {
  padrão: 'inherit',
  moderno: 'system-ui, sans-serif',
  clássico: 'Georgia, serif',
  serif: 'Georgia, serif',
  mono: 'ui-monospace, monospace',
};

function cents(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.max(0, Math.round(parsed)) : 0;
}

function money(value) {
  return currency.format(cents(value) / 100);
}

function normalize(text) {
  return String(text ?? '').normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase().trim();
}

function initials(name) {
  return String(name || 'Vitrine').trim().split(/\s+/).slice(0, 2).map((word) => word[0]).join('').toUpperCase();
}

function color(value, fallback) {
  const hex = /^#([\da-f]{3}|[\da-f]{6})$/i.exec(value || '')?.[1];
  if (!hex) return fallback;
  return hex.length === 3 ? '#' + [...hex].map((digit) => digit + digit).join('') : '#' + hex;
}

function readableText(background) {
  const channels = background.slice(1).match(/.{2}/g).map((hex) => parseInt(hex, 16) / 255);
  const linear = channels.map((channel) => (
    channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4
  ));
  const luminance = 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2];
  return luminance > 0.179 ? '#151515' : '#fff';
}

function catalogImage(url) {
  if (typeof url !== 'string') return undefined;
  const input = url.trim();
  if (/^\/(?![\/\\])/.test(input) || /^https?:\/\//i.test(input) || /^data:image\/(?:png|jpeg|webp|gif);base64,/i.test(input)) {
    return input;
  }
  return undefined;
}

function Image({ url, name, className, eager = false }) {
  const [brokenUrl, setBrokenUrl] = useState('');
  const source = catalogImage(url);
  return (
    <div className={className}>
      <span aria-hidden="true">{initials(name)}</span>
      {source && source !== brokenUrl && (
        <img src={source} alt="" loading={eager ? 'eager' : 'lazy'} onError={() => setBrokenUrl(source)} />
      )}
    </div>
  );
}

function Product({ product, quantity, limitReached, add }) {
  return (
    <article className="vs-product">
      <Image url={product.imageUrl} name={product.name} className="vs-product-image" />
      <div className="vs-product-content">
        {product.category && <p className="vs-category">{product.category}</p>}
        <h3>{product.name}</h3>
        {product.description && <p className="vs-description">{product.description}</p>}
        <div className="vs-product-bottom">
          <strong>{money(product.priceCents)}</strong>
          <button
            type="button"
            className="vs-add"
            aria-label={`Adicionar ${product.name} à sacola`}
            disabled={quantity >= maxQuantity || (limitReached && !quantity)}
            onClick={() => add(product.id)}
          >
            <span aria-hidden="true">+</span> Adicionar
          </button>
        </div>
      </div>
    </article>
  );
}

function CartLine({ product, quantity, change }) {
  return (
    <li className="vs-cart-line">
      <Image url={product.imageUrl} name={product.name} className="vs-cart-image" />
      <div className="vs-cart-item">
        <strong>{product.name}</strong>
        <span>{money(cents(product.priceCents) * quantity)}</span>
        <div className="vs-stepper">
          <button type="button" onClick={() => change(product.id, -1)} aria-label={`Diminuir quantidade de ${product.name}`}>−</button>
          <span aria-label={`Quantidade de ${product.name}`}>{quantity}</span>
          <button type="button" disabled={quantity >= maxQuantity} onClick={() => change(product.id, 1)} aria-label={`Aumentar quantidade de ${product.name}`}>+</button>
        </div>
      </div>
      <button type="button" className="vs-link-button" onClick={() => change(product.id, -quantity)} aria-label={`Remover ${product.name}`}>Remover</button>
    </li>
  );
}

function paymentLabel(value) {
  return { pix: 'Pix', cash: 'Dinheiro', dinheiro: 'Dinheiro', card: 'Cartão', cartao: 'Cartão' }[normalize(value)] || value;
}

function orderLink(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && ['wa.me', 'api.whatsapp.com'].includes(url.hostname) ? url.href : null;
  } catch {
    return null;
  }
}

export default function Storefront({ store, products = [], api, href = '/' }) {
  const searchId = useId();
  const drawerTitle = useId();
  const filterLabel = useId();
  const dialog = useRef(null);
  const nameInput = useRef(null);
  const submitLock = useRef(false);
  const requestId = useRef(null);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [quantities, setQuantities] = useState({});
  const [loadedSlug, setLoadedSlug] = useState('');
  const [announcement, setAnnouncement] = useState('');
  const [checkout, setCheckout] = useState(false);
  const [fulfillment, setFulfillment] = useState('pickup');
  const [submitting, setSubmitting] = useState(false);
  const [confirmation, setConfirmation] = useState(null);
  const [error, setError] = useState('');

  const available = useMemo(() => products.filter((product) => product.available !== false && product.available !== 0), [products]);
  const categories = useMemo(() => [...new Set(available.map((product) => product.category).filter(Boolean))]
    .sort((left, right) => left.localeCompare(right, 'pt-BR')), [available]);
  const filtered = available.filter((product) => (
    (!category || product.category === category) &&
      normalize(`${product.name} ${product.description ?? ''} ${product.category ?? ''}`).includes(normalize(search))
  ));

  const cartItems = available.flatMap((product) => {
    const quantity = quantities[product.id];
    return Number.isInteger(quantity) && quantity > 0 ? [{ product, quantity }] : [];
  });
  const itemCount = cartItems.reduce((count, entry) => count + entry.quantity, 0);
  const subtotal = cartItems.reduce((total, entry) => total + cents(entry.product.priceCents) * entry.quantity, 0);
  const delivery = Boolean(store.deliveryEnabled) && fulfillment === 'delivery';
  const deliveryFee = delivery ? cents(store.deliveryFeeCents) : 0;
  const paymentMethods = Array.isArray(store.paymentMethods) ? store.paymentMethods.filter(Boolean) : [];
  const theme = color(store.primaryColor, '#e76824');
  const background = color(store.backgroundColor, '#faf6ef');
  const banner = catalogImage(store.bannerUrl);

  useEffect(() => {
    let remembered = {};
    try {
      const saved = JSON.parse(localStorage.getItem(`vitrine.cart:${store.slug}`) || '{}');
      if (saved && typeof saved === 'object' && !Array.isArray(saved)) {
        remembered = Object.fromEntries(Object.entries(saved).filter(([, quantity]) =>
          Number.isInteger(quantity) && quantity > 0 && quantity <= maxQuantity));
      }
    } catch {
      // Continue in memory when the browser blocks local storage.
    }
    setQuantities(remembered);
    setLoadedSlug(store.slug);
  }, [store.slug]);

  useEffect(() => {
    if (loadedSlug !== store.slug) return;
    try {
      localStorage.setItem(`vitrine.cart:${store.slug}`, JSON.stringify(quantities));
    } catch {
      // The cart still works in the current tab.
    }
  }, [loadedSlug, quantities, store.slug]);

  useEffect(() => {
    if (checkout) nameInput.current?.focus();
  }, [checkout]);

  function changeQuantity(id, amount) {
    setQuantities((current) => {
      const next = { ...current };
      const quantity = Math.min(maxQuantity, (current[id] || 0) + amount);
      if (quantity > 0) next[id] = quantity;
      else delete next[id];
      return next;
    });
    if (amount > 0) {
      setConfirmation(null);
      const product = available.find((item) => item.id === id);
      if (product) setAnnouncement(`${product.name} adicionado à sacola.`);
    }
  }

  function showCart() {
    if (!dialog.current?.open) dialog.current?.showModal();
  }

  function closeCart() {
    dialog.current?.close();
  }

  async function submitOrder(event) {
    event.preventDefault();
    if (submitLock.current || !cartItems.length) return;
    submitLock.current = true;
    setSubmitting(true);
    setError('');
    const details = new FormData(event.currentTarget);

    try {
      requestId.current ||= globalThis.crypto.randomUUID();
      const result = await api(`public/${encodeURIComponent(store.slug)}/orders`, {
        method: 'POST',
        body: {
          requestId: requestId.current,
          customerName: String(details.get('customerName') || '').trim(),
          fulfillment: delivery ? 'delivery' : 'pickup',
          address: delivery ? String(details.get('address') || '').trim() : '',
          paymentMethod: String(details.get('paymentMethod') || ''),
          notes: String(details.get('notes') || '').trim(),
          items: cartItems.map(({ product, quantity }) => ({ productId: product.id, quantity })),
        },
      });
      setConfirmation({ order: result.order, whatsappUrl: orderLink(result.whatsappUrl) });
      requestId.current = null;
      setQuantities({});
      setCheckout(false);
    } catch (failure) {
      setError(failure.message || 'Não foi possível preparar seu pedido. Tente novamente.');
    } finally {
      submitLock.current = false;
      setSubmitting(false);
    }
  }

  return (
    <div
      className="v-store"
      style={{
        '--vs-theme': theme,
        '--vs-theme-ink': readableText(theme),
        '--vs-canvas': background,
        '--vs-canvas-ink': readableText(background),
        '--vs-store-font': supportedFonts[store.font?.toLowerCase()] || 'inherit',
      }}
    >
      <header className="vs-header">
        <div className="vs-width vs-header-content">
          <a className="vs-brand" href={href}>vitrine<span aria-hidden="true">.</span></a>
          <button type="button" className="vs-bag" onClick={showCart}>
            <span className="vs-bag-icon" aria-hidden="true" />
            Sacola <span className="vs-bag-count">{itemCount}</span>
          </button>
        </div>
      </header>

      <main className="vs-width vs-main">
        <section className={banner ? 'vs-hero vs-has-banner' : 'vs-hero'} aria-labelledby={`${searchId}-store`}>
          {banner && <img className="vs-hero-banner" src={banner} alt="" />}
          <div className="vs-hero-content">
            <Image className="vs-shopmark" url={store.logoUrl} name={store.name} eager />
            <div className="vs-shop-info">
              <h1 id={`${searchId}-store`}>{store.name}</h1>
              {store.description && <p>{store.description}</p>}
              {store.isDemo && <span className="vs-demo">Loja de demonstração</span>}
            </div>
          </div>
        </section>

        <section className="vs-catalog" aria-labelledby={`${searchId}-catalog`}>
          <div className="vs-catalog-heading">
            <h2 id={`${searchId}-catalog`}>Produtos</h2>
            <div className="vs-search">
              <label className="vs-a11y" htmlFor={searchId}>Buscar produtos</label>
              <span className="vs-search-icon" aria-hidden="true" />
              <input id={searchId} type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Buscar produtos" />
            </div>
          </div>

          {!!categories.length && (
            <div className="vs-filters" role="group" aria-labelledby={filterLabel}>
              <span className="vs-a11y" id={filterLabel}>Categorias</span>
              {['', ...categories].map((value) => (
                <button key={value} type="button" aria-pressed={value === category} onClick={() => setCategory(value)}>
                  {value || 'Todos'}
                </button>
              ))}
            </div>
          )}

          {filtered.length ? (
            <>
              {cartItems.length >= maxProducts && <p className="vs-limit">A sacola comporta até {maxProducts} produtos diferentes.</p>}
              <div className="vs-grid">
                {filtered.map((product) => (
                  <Product
                    key={product.id}
                    product={product}
                    quantity={quantities[product.id] || 0}
                    limitReached={cartItems.length >= maxProducts}
                    add={(id) => changeQuantity(id, 1)}
                  />
                ))}
              </div>
            </>
          ) : (
            <div className="vs-empty">
              <strong>{available.length ? 'Nenhum produto encontrado' : 'Nenhum produto disponível'}</strong>
              {available.length > 0 && (
                <button type="button" className="vs-outline" onClick={() => { setSearch(''); setCategory(''); }}>Limpar filtros</button>
              )}
            </div>
          )}
        </section>
      </main>

      <p className="vs-a11y" aria-live="polite">{announcement}</p>

      <dialog ref={dialog} className="vs-dialog" aria-labelledby={drawerTitle} onClick={(event) => {
        if (event.target === event.currentTarget) {
          const bounds = event.currentTarget.getBoundingClientRect();
          if (event.clientX < bounds.left || event.clientX > bounds.right) closeCart();
        }
      }}>
        <header className="vs-drawer-head">
          <h2 id={drawerTitle}>{confirmation ? 'Resumo do pedido' : 'Sua sacola'}</h2>
          <button type="button" className="vs-close" onClick={closeCart} aria-label="Fechar sacola">×</button>
        </header>

        {confirmation ? (
          <div className="vs-cart-message" aria-live="polite">
            <strong>{confirmation.whatsappUrl ? 'Seu pedido está pronto para enviar' : store.isDemo ? 'Pedido simulado' : 'Pedido registrado'}</strong>
            {confirmation.whatsappUrl && <p>Abra o WhatsApp para enviar os itens e o total à loja.</p>}
            {store.isDemo && <p>Esta loja é uma demonstração.</p>}
            {confirmation.whatsappUrl ? (
              <a className="vs-primary" href={confirmation.whatsappUrl} target="_blank" rel="noopener noreferrer">Abrir WhatsApp</a>
            ) : (
              <button type="button" className="vs-primary" onClick={closeCart}>Voltar à loja</button>
            )}
          </div>
        ) : cartItems.length === 0 ? (
          <div className="vs-cart-message">
            <strong>Sua sacola está vazia</strong>
            <p>Adicione produtos do catálogo para montar seu pedido.</p>
            <button type="button" className="vs-outline" onClick={closeCart}>Ver produtos</button>
          </div>
        ) : (
          <>
            <ul className="vs-cart-items">
              {cartItems.map(({ product, quantity }) => (
                <CartLine key={product.id} product={product} quantity={quantity} change={changeQuantity} />
              ))}
            </ul>

            {checkout && (
              <form id={`${searchId}-checkout`} className="vs-checkout" onSubmit={submitOrder}>
                <h3>Dados do pedido</h3>
                <label>Seu nome
                  <input ref={nameInput} name="customerName" autoComplete="name" maxLength={100} required />
                </label>
                {Boolean(store.deliveryEnabled) && (
                  <label>Como deseja receber?
                    <select value={fulfillment} onChange={(event) => setFulfillment(event.target.value)}>
                      <option value="pickup">Retirar na loja</option>
                      <option value="delivery">Receber em casa</option>
                    </select>
                  </label>
                )}
                {delivery && (
                  <label>Endereço para entrega
                    <textarea name="address" autoComplete="street-address" placeholder="Rua, número, bairro e cidade" rows={2} maxLength={250} required />
                  </label>
                )}
                {!!paymentMethods.length && (
                  <label>Forma de pagamento
                    <select required name="paymentMethod" defaultValue="">
                      <option value="" disabled>Selecione</option>
                      {paymentMethods.map((method) => <option key={method} value={method}>{paymentLabel(method)}</option>)}
                    </select>
                  </label>
                )}
                <label>Observações <span>(opcional)</span>
                  <textarea name="notes" rows={2} maxLength={300} />
                </label>
                {error && <p className="vs-error" role="alert">{error}</p>}
              </form>
            )}

            <footer className="vs-cart-summary">
              {delivery && (
                <div className="vs-summary-detail"><span>Entrega</span><span>{deliveryFee ? money(deliveryFee) : 'Grátis'}</span></div>
              )}
              <div className="vs-summary-total"><span>{checkout ? 'Total' : 'Subtotal'}</span><strong>{money(subtotal + deliveryFee)}</strong></div>
              {checkout ? (
                <button type="submit" form={`${searchId}-checkout`} className="vs-primary" disabled={submitting}>
                  {submitting ? 'Preparando pedido…' : store.isDemo ? 'Simular pedido' : 'Confirmar pedido'}
                </button>
              ) : (
                <button type="button" className="vs-primary" onClick={() => setCheckout(true)}>Continuar pedido</button>
              )}
            </footer>
          </>
        )}
      </dialog>
    </div>
  );
}
