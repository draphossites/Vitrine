"use client";
import { useCallback, useEffect, useState } from "react";
import { AppMark, Icon } from "./Chrome.jsx";
import { api } from "./api.js";
import Admin from "./Admin.jsx";
import Merchant from "./Merchant.jsx";
import "./master-login.css";

const merchantTabs = [["overview","Visão geral"],["products","Produtos"],["orders","Pedidos"],["customize","Personalização"],["subscription","Assinatura"],["account","Acesso"]];
const adminTabs = [["overview","Resumo"],["approvals","Aprovação de pagamentos"],["stores","Lojas"],["subscriptions","Assinaturas"],["users","Usuários"],["history","Histórico"]];

function MasterLogin() {
  const [submitting, setSubmitting] = useState(false);
  const [loginError, setLoginError] = useState("");

  async function handleLogin(event) {
    event.preventDefault();
    if (submitting) return;
    const form = new FormData(event.currentTarget);
    setLoginError("");
    setSubmitting(true);
    try {
      await api("master/login", {
        method: "POST",
        body: { email: form.get("email"), password: form.get("password") },
      });
      window.location.reload();
    } catch (error) {
      setLoginError(error instanceof TypeError ? "Não foi possível conectar. Tente novamente." : error.message);
      setSubmitting(false);
    }
  }

  return <main className="gate-card master-login" aria-labelledby="master-login-title">
    <span className="master-login-icon"><Icon kind="lock" size={26}/></span>
    <h1 id="master-login-title">Entrar no Adimin</h1>
    <p>Use seu e-mail e sua senha do Adimin.</p>
    <form method="post" onSubmit={handleLogin} className="master-login-form" aria-busy={submitting}>
      <label htmlFor="master-email">E-mail</label>
      <input id="master-email" name="email" type="email" autoComplete="username" autoCapitalize="none" spellCheck={false} maxLength={254} required/>
      <label htmlFor="master-password">Senha</label>
      <input id="master-password" name="password" type="password" autoComplete="current-password" maxLength={256} required/>
      {loginError && <div className="master-login-error" role="alert">{loginError}</div>}
      <button type="submit" className="button button-primary" disabled={submitting}>{submitting ? "Entrando…" : "Entrar"}</button>
    </form>
    <span className="master-login-status" role="status">{submitting ? "Entrando no Adimin…" : ""}</span>
  </main>;
}

export function Dashboard({ mode, authenticated, masterLoginAvailable = false, initialTab = "overview" }) {
  const admin = mode === "admin";
  const needsMasterLogin = admin && masterLoginAvailable && !authenticated;
  const tabs = admin ? adminTabs : merchantTabs;
  const [tab, setTab] = useState(initialTab);
  const [data, setData] = useState(null);
  const [loadError, setLoadError] = useState("");
  const [loggingOut, setLoggingOut] = useState(false);
  const [logoutError, setLogoutError] = useState("");
  const refresh = useCallback(async () => {
    setLoadError("");
    try {
      const result = await api(mode);
      setData(result);
    } catch (error) {
      setLoadError(error.message);
      throw error;
    }
  }, [mode]);
  useEffect(() => {
    if (authenticated) refresh().catch(() => {});
  }, [authenticated, refresh]);

  async function handlePanelLogout() {
    if (loggingOut) return;
    setLogoutError("");
    setLoggingOut(true);
    try {
      await api(admin ? "master/logout" : "account/logout", { method: "POST" });
      if (admin) window.location.reload();
      else window.location.assign("/entrar");
    } catch {
      setLogoutError("Não foi possível sair. Tente novamente.");
      setLoggingOut(false);
    }
  }

  return <>
    <header className="site-header"><div className="header-inner dashboard-header">
      <div className="dashboard-ident"><AppMark/>{admin && <span className="master-label">Adimin</span>}</div>
      {authenticated && (admin || data?.store) && <nav aria-label={admin ? "Painel Adimin" : "Painel do lojista"} className="dashboard-nav">
        {tabs.map(([id,label]) => <button type="button" key={id} aria-current={tab === id ? "page" : undefined} onClick={() => setTab(id)}>{label}</button>)}
      </nav>}
      <div className="dashboard-account">
        {authenticated && <button type="button" className="plain-link master-logout" disabled={loggingOut} onClick={handlePanelLogout}>
          {loggingOut ? "Saindo…" : admin ? "Sair do Adimin" : "Sair"}
        </button>}
      </div>
    </div></header>
    {logoutError && <div className="master-logout-error" role="alert">{logoutError}</div>}
    {needsMasterLogin ? <MasterLogin/> : !authenticated ? <main className="gate-card">
      <Icon kind={admin ? "lock" : "store"} size={32}/>
      <h1>{admin ? "Painel Adimin" : "Painel do lojista"}</h1>
      <p>{admin ? "O acesso ao Adimin está indisponível no momento." : "Entre com seu e-mail e senha para gerenciar sua loja."}</p>
      {!admin && <>
        <a className="button button-primary" href="/entrar">Entrar</a>{" "}
        <a className="button button-secondary" href="/cadastro">Cadastrar loja</a>
      </>}
    </main> : <>
      {loadError && <div className="dashboard-error" role="alert">{loadError} <button className="button button-secondary" onClick={() => refresh().catch(() => {})}>Tentar novamente</button></div>}
      {!data && !loadError && <div className="dashboard-loading" role="status">Carregando painel…</div>}
      {data && (admin
        ? <Admin data={data} api={api} onRefresh={refresh} onNavigate={setTab} tab={tab}/>
        : <Merchant {...data} api={api} onRefresh={refresh} onNavigate={setTab} tab={tab}/>)}
    </>}
  </>;
}
