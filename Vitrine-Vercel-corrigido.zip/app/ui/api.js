export async function api(path, {method = "GET", body} = {}) {
  const multipart = body instanceof FormData;
  const response = await fetch("/api/vitrine/" + path, {
    method,
    headers: body && !multipart ? { "Content-Type": "application/json" } : undefined,
    body: body ? (multipart ? body : JSON.stringify(body)) : undefined,
    cache: "no-store",
  });
  const result = await response.json().catch(() => null);
  if (!response.ok || !result) throw new Error(result?.error || "Não foi possível carregar os dados. Tente novamente.");
  return result;
}
