"use client";
import Storefront from "./Storefront.jsx";
import { api } from "./api.js";
export function Catalog({store,products}) {
  return <Storefront store={store} products={products} api={api}/>;
}
