'use client';

import { useEffect, useRef, useState } from 'react';
import './merchant.css';

const money = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const dateTime = new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short', timeZone: 'America/Sao_Paulo' });
const paymentMethods = { pix: 'Pix', card: 'Cartão', cash: 'Dinheiro' };
const fonts = { system: 'Padrão da Vitrine', sans: 'Sem serifa', serif: 'Com serifa', mono: 'Monoespaçada' };
const orderStatuses = { open: 'Novo', confirmed: 'Confirmado', completed: 'Concluído', cancelled: 'Cancelado' };
const subscriptionStatuses = { active: 'Ativa', pending: 'Pendente', expired: 'Vencida', blocked: 'Bloqueada', inactive: 'Inativa', trial: 'Em teste' };
const paymentStatuses = { pending: 'Em análise', approved: 'Aprovado', rejected: 'Recusado' };

function price(cents) {
  return money.format(Number(cents || 0) / 100);
}

function decimal(cents) {
  return (Number(cents || 0) / 100).toFixed(2).replace('.', ',');
}

function readCents(value) {
  const normalized = value.trim().replace(/\s/gu, '');
  const plain = normalized.includes(',') ? normalized.replace(/\./gu, '').replace(',', '.') : normalized;
  if (!/^\d+(?:\.\d{1,2})?$/u.test(plain)) return null;
  const cents = Math.round(Number(plain) * 100);
  return Number.isSafeInteger(cents) ? cents : null;
}

function displayDate(value) {
  if (!value) return '';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '' : dateTime.format(date);
}

function slugify(value) {
  return value.normalize('NFD').replace(/[\u0300-\u036f]/gu, '').toLowerCase().replace(/[^a-z0-9]+/gu, '-').replace(/^-+|-+$/gu, '');
}

function imageSource(value) {
  return /^(https?:\/\/|\/(?!\/))/iu.test(value || '') ? value : '';
}

function Badge({ status, labels }) {
  return <span className="merchant__badge" data-status={status}>{labels[status] || status || 'Pendente'}</span>;
}

function PageHeading({ title, description, children }) {
  return <header className="merchant__heading">
    <div><h1>{title}</h1>{description && <p>{description}</p>}</div>
    {children}
  </header>;
}

function Empty({ title, description, children }) {
  return <div className="merchant__card merchant__empty"><h2>{title}</h2>{description && <p>{description}</p>}{children}</div>;
}

function UploadField({ label, url, onUrl, file, onFile }) {
  return <div className="merchant__upload">
    <label className="merchant__field">
      <span>{label}</span>
      <input type="file" accept="image/jpeg,image/png,image/webp,image/avif" onChange={(event) => onFile(event.target.files?.[0] || null)} />
    </label>
    {!file && url && <div className="merchant__upload-current">
      {imageSource(url) && <img src={imageSource(url)} alt="" />}
      <button className="merchant__button merchant__button--plain" type="button" onClick={() => onUrl('')}>Remover imagem</button>
    </div>}
    <label className="merchant__field">
      <span>Link da imagem (opcional)</span>
      <input type="text" inputMode="url" placeholder="https://" value={url ?? ''} onChange={(event) => onUrl(event.target.value)} />
    </label>
  </div>;
}

async function upload(api, file, existingUrl) {
  if (!file) return existingUrl?.trim() || '';
  const body = new FormData();
  body.set('file', file);
  return (await api('merchant/upload', { method: 'POST', body })).url;
}

function Onboarding({ act, pending }) {
  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [customSlug, setCustomSlug] = useState(false);

  async function submit(event) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    await act('store', (api) => api('merchant/store', {
      method: 'POST',
      body: { name: name.trim(), slug: slug.trim(), whatsapp: form.get('whatsapp').trim(), description: form.get('description').trim() },
    }), 'Loja criada. Agora você pode cadastrar seus produtos.');
  }

  return <>
    <PageHeading title="Crie sua loja" description="Configure o nome e o WhatsApp para cadastrar seus primeiros produtos." />
    <form className="merchant__card merchant__form merchant__form--narrow" onSubmit={submit}>
      <fieldset disabled={pending}>
        <label className="merchant__field"><span>Nome da loja</span><input autoComplete="organization" required maxLength={100} value={name} onChange={(event) => {
          setName(event.target.value);
          if (!customSlug) setSlug(slugify(event.target.value));
        }} placeholder="Ex.: Minha Loja" /></label>
        <label className="merchant__field"><span>Endereço da vitrine</span><div className="merchant__input-prefix"><span>/loja/</span><input required minLength={3} maxLength={55} value={slug} pattern="[a-z0-9]+(?:-[a-z0-9]+)*" onChange={(event) => {
          setCustomSlug(true);
          setSlug(event.target.value.toLowerCase());
        }} placeholder="minha-loja" /></div><small>Use letras minúsculas, números e hífens.</small></label>
        <label className="merchant__field"><span>WhatsApp com DDD</span><input name="whatsapp" type="tel" autoComplete="tel" placeholder="(11) 99999-9999" required /></label>
        <label className="merchant__field"><span>Descrição da loja (opcional)</span><textarea name="description" maxLength={500} rows={3} placeholder="Conte aos clientes o que sua loja vende." /></label>
        <button className="merchant__button merchant__button--primary" type="submit">{pending ? 'Criando loja…' : 'Criar loja'}</button>
      </fieldset>
    </form>
  </>;
}

function Overview({ store, products, orders, onNavigate }) {
  const [copyStatus, setCopyStatus] = useState('');
  const link = `/loja/${encodeURIComponent(store.slug)}`;
  const openOrders = orders.filter((order) => order.status === 'open').length;
  const availableProducts = products.filter((product) => product.available).length;
  const [publicUrl, setPublicUrl] = useState(link);

  useEffect(() => setPublicUrl(new URL(link, window.location.origin).href), [link]);

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(publicUrl);
      setCopyStatus('Link copiado');
    } catch {
      setCopyStatus('Selecione o endereço acima para copiar.');
    }
  }

  return <>
    <PageHeading title={store.name} description="Gerencie seu catálogo e acompanhe os pedidos da sua loja.">
      <Badge status={store.status || 'active'} labels={{ ...subscriptionStatuses, paused: 'Pausada' }} />
    </PageHeading>
    <div className="merchant__metrics">
      <section className="merchant__card merchant__metric"><span>Produtos cadastrados</span><strong>{products.length}</strong><small>{availableProducts} disponíveis</small></section>
      <section className="merchant__card merchant__metric"><span>Pedidos novos</span><strong>{openOrders}</strong><small>{orders.length} registrados</small></section>
      <section className="merchant__card merchant__metric"><span>Assinatura</span><strong className="merchant__metric-text">{subscriptionStatuses[store.subscriptionStatus] || 'Pendente'}</strong>{store.subscriptionExpiresAt && <small>Validade {displayDate(store.subscriptionExpiresAt)}</small>}</section>
    </div>
    <div className="merchant__overview-grid">
      <section className="merchant__card merchant__overview-card">
        <h2>Link da sua loja</h2>
        <p className="merchant__url">{publicUrl}</p>
        <div className="merchant__actions">
          <button className="merchant__button merchant__button--primary" type="button" onClick={copyLink}>Copiar link</button>
          <a className="merchant__button" href={link} target="_blank" rel="noopener noreferrer">Abrir vitrine</a>
        </div>
        {copyStatus && <small role="status">{copyStatus}</small>}
      </section>
      <section className="merchant__card merchant__overview-card">
        <h2>Organize sua loja</h2>
        <p>Cadastre os itens que você vende e atualize o visual da vitrine.</p>
        <div className="merchant__actions">
          <button className="merchant__button" type="button" onClick={() => onNavigate?.('products')}>Gerenciar produtos</button>
          <button className="merchant__button" type="button" onClick={() => onNavigate?.('customize')}>Personalizar</button>
        </div>
      </section>
    </div>
  </>;
}

function Modal({ title, onClose, children }) {
  const dialogRef = useRef(null);

  useEffect(() => dialogRef.current?.showModal(), []);

  return <dialog ref={dialogRef} className="merchant__dialog" aria-labelledby="merchant-dialog-title" onCancel={(event) => {
    event.preventDefault();
    onClose();
  }}>
    <header><h2 id="merchant-dialog-title">{title}</h2><button className="merchant__icon" type="button" aria-label="Fechar" onClick={onClose}>×</button></header>
    {children}
  </dialog>;
}

function ProductEditor({ product, act, onClose, pending }) {
  const [imageUrl, setImageUrl] = useState(product?.imageUrl ?? '');
  const [file, setFile] = useState(null);
  const [validation, setValidation] = useState('');

  async function submit(event) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const priceCents = readCents(form.get('price'));
    if (priceCents === null) {
      setValidation('Informe um preço válido, como 19,90.');
      return;
    }
    setValidation('');
    const saved = await act('product-save', async (api) => {
      const body = {
        name: form.get('name').trim(), category: form.get('category').trim(), description: form.get('description').trim(),
        priceCents, available: form.has('available'), imageUrl: await upload(api, file, imageUrl),
      };
      return api(product ? `merchant/products/${encodeURIComponent(product.id)}` : 'merchant/products', { method: product ? 'PATCH' : 'POST', body });
    }, product ? 'Produto atualizado.' : 'Produto cadastrado.', setValidation);
    if (saved) onClose(true);
  }

  return <Modal title={product ? 'Editar produto' : 'Novo produto'} onClose={onClose}>
    <form className="merchant__form" onSubmit={submit}>
      <fieldset disabled={pending}>
        <label className="merchant__field"><span>Nome do produto</span><input name="name" required maxLength={120} defaultValue={product?.name} autoFocus /></label>
        <div className="merchant__fields-two">
          <label className="merchant__field"><span>Preço (R$)</span><input name="price" inputMode="decimal" placeholder="0,00" required defaultValue={product ? decimal(product.priceCents) : ''} /></label>
          <label className="merchant__field"><span>Categoria (opcional)</span><input name="category" maxLength={70} defaultValue={product?.category} /></label>
        </div>
        <label className="merchant__field"><span>Descrição (opcional)</span><textarea name="description" rows={3} maxLength={1000} defaultValue={product?.description} /></label>
        <UploadField label="Foto do produto" url={imageUrl} onUrl={setImageUrl} file={file} onFile={setFile} />
        <label className="merchant__check"><input type="checkbox" name="available" defaultChecked={product?.available ?? true} />Disponível na vitrine</label>
        {validation && <p className="merchant__error" role="alert">{validation}</p>}
        <div className="merchant__actions">
          <button className="merchant__button merchant__button--primary" type="submit">{pending ? 'Salvando…' : 'Salvar produto'}</button>
          <button className="merchant__button" type="button" onClick={onClose}>Cancelar</button>
        </div>
      </fieldset>
    </form>
  </Modal>;
}

function Products({ products, act, pending }) {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('all');
  const [editor, setEditor] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [deleteError, setDeleteError] = useState('');
  const matches = products.filter((product) => {
    const text = `${product.name} ${product.category ?? ''}`.toLocaleLowerCase('pt-BR');
    return text.includes(query.trim().toLocaleLowerCase('pt-BR')) && (filter === 'all' || Boolean(product.available) === (filter === 'available'));
  });

  async function confirmDelete() {
    const removed = await act(`delete:${deleting.id}`, (api) => api(`merchant/products/${encodeURIComponent(deleting.id)}`, { method: 'DELETE' }), 'Produto removido.', setDeleteError);
    if (removed) setDeleting(null);
  }

  return <>
    <PageHeading title="Produtos" description="Cadastre produtos, ajuste preços e controle o que aparece no catálogo.">
      <button className="merchant__button merchant__button--primary" type="button" onClick={() => setEditor({ product: null })}><span aria-hidden="true">+</span> Novo produto</button>
    </PageHeading>
    {products.length > 0 && <div className="merchant__toolbar">
      <input type="search" aria-label="Buscar produtos" placeholder="Buscar por nome ou categoria" value={query} onChange={(event) => setQuery(event.target.value)} />
      <select aria-label="Filtrar por disponibilidade" value={filter} onChange={(event) => setFilter(event.target.value)}>
        <option value="all">Todos os produtos</option><option value="available">Disponíveis</option><option value="unavailable">Indisponíveis</option>
      </select>
    </div>}
    {matches.length > 0 ? <ul className="merchant__product-list">{matches.map((product) => <li key={product.id} className="merchant__card merchant__product">
      {imageSource(product.imageUrl) ? <img className="merchant__product-photo" src={imageSource(product.imageUrl)} alt="" loading="lazy" /> : <div className="merchant__product-photo merchant__placeholder" aria-hidden="true">{product.name.slice(0, 1).toUpperCase()}</div>}
      <div className="merchant__product-detail"><strong>{product.name}</strong><span>{price(product.priceCents)}{product.category && ` · ${product.category}`}</span></div>
      <div className="merchant__product-actions">
        <label className="merchant__toggle"><input type="checkbox" role="switch" checked={Boolean(product.available)} disabled={Boolean(pending)} aria-label={`Disponibilidade de ${product.name}`} onChange={(event) => {
          const available = event.target.checked;
          act(`availability:${product.id}`, (api) => api(`merchant/products/${encodeURIComponent(product.id)}`, { method: 'PATCH', body: { available } }), available ? 'Produto disponível na vitrine.' : 'Produto retirado da vitrine.');
        }} /><span>{product.available ? 'Disponível' : 'Indisponível'}</span></label>
        <button type="button" className="merchant__button merchant__button--plain" onClick={() => setEditor({ product })}>Editar</button>
        <button type="button" className="merchant__button merchant__button--plain merchant__button--danger-text" onClick={() => { setDeleting(product); setDeleteError(''); }}>Excluir</button>
      </div>
    </li>)}</ul> : <Empty title={products.length ? 'Nenhum resultado' : 'Seu catálogo está vazio'} description={products.length ? 'Tente buscar por outro termo ou alterar o filtro.' : 'Cadastre seu primeiro produto para exibi-lo na vitrine.'} />}
    {editor && <ProductEditor key={editor.product?.id ?? 'new'} product={editor.product} act={act} pending={pending === 'product-save'} onClose={(saved) => { if (!pending || saved === true) setEditor(null); }} />}
    {deleting && <Modal title="Excluir produto" onClose={() => { if (!pending) setDeleting(null); }}>
      <p>Excluir <strong>{deleting.name}</strong> do seu catálogo?</p>
      {deleteError && <p className="merchant__error" role="alert">{deleteError}</p>}
      <div className="merchant__actions"><button className="merchant__button merchant__button--danger" type="button" disabled={Boolean(pending)} onClick={confirmDelete}>{pending ? 'Excluindo…' : 'Excluir produto'}</button><button className="merchant__button" type="button" disabled={Boolean(pending)} onClick={() => setDeleting(null)}>Cancelar</button></div>
    </Modal>}
  </>;
}

function Orders({ orders, act, pending }) {
  const [filter, setFilter] = useState('all');
  const visible = orders.filter((order) => filter === 'all' || order.status === filter);
  return <>
    <PageHeading title="Pedidos" description="Acompanhe os pedidos gerados na sua vitrine." />
    {orders.length > 0 && <div className="merchant__toolbar"><select aria-label="Filtrar pedidos por situação" value={filter} onChange={(event) => setFilter(event.target.value)}><option value="all">Todos os pedidos</option>{Object.entries(orderStatuses).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></div>}
    {visible.length ? <div className="merchant__order-list">{visible.map((order) => <details className="merchant__card merchant__order" key={order.id}>
      <summary><div><strong>{order.customerName || 'Pedido sem nome'}</strong><small>{displayDate(order.createdAt)}{order.fulfillment && ` · ${order.fulfillment === 'delivery' ? 'Entrega' : 'Retirada'}`}</small></div><Badge status={order.status} labels={orderStatuses} /><strong>{price(order.totalCents)}</strong></summary>
      <div className="merchant__order-body">
        <ul>{(order.items || []).map((item, index) => <li key={item.productId ?? index}><span>{item.quantity} × {item.name}</span><span>{price(item.quantity * item.priceCents)}</span></li>)}</ul>
        {order.address && <p><strong>Endereço:</strong> {order.address}</p>}
        {order.paymentMethod && <p><strong>Pagamento:</strong> {paymentMethods[order.paymentMethod] || order.paymentMethod}</p>}
        {order.notes && <p><strong>Observações:</strong> {order.notes}</p>}
        <label className="merchant__field"><span>Situação do pedido</span><select value={order.status} disabled={Boolean(pending)} onChange={(event) => {
          const status = event.target.value;
          act(`order:${order.id}`, (api) => api(`merchant/orders/${encodeURIComponent(order.id)}`, { method: 'PATCH', body: { status } }), 'Situação do pedido atualizada.');
        }}>{Object.entries(orderStatuses).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
      </div>
    </details>)}</div> : <Empty title={orders.length ? 'Nenhum pedido nessa situação' : 'Nenhum pedido registrado'} description={orders.length ? 'Altere o filtro para ver os demais pedidos.' : 'Os pedidos enviados pelo catálogo aparecem aqui.'} />}
  </>;
}

function Customize({ store, act, pending }) {
  const [logoUrl, setLogoUrl] = useState(store.logoUrl || '');
  const [logoFile, setLogoFile] = useState(null);
  const [bannerUrl, setBannerUrl] = useState(store.bannerUrl || '');
  const [bannerFile, setBannerFile] = useState(null);
  const [deliveryEnabled, setDeliveryEnabled] = useState(Boolean(store.deliveryEnabled));
  const [validation, setValidation] = useState('');

  async function submit(event) {
    event.preventDefault();
    const element = event.currentTarget;
    const form = new FormData(element);
    const deliveryFeeCents = deliveryEnabled ? readCents(form.get('deliveryFee')) : Number(store.deliveryFeeCents || 0);
    if (deliveryFeeCents === null) {
      setValidation('Informe uma taxa válida, como 9,00.');
      return;
    }
    setValidation('');
    let newLogoUrl;
    let newBannerUrl;
    const saved = await act('customize', async (api) => {
      newLogoUrl = await upload(api, logoFile, logoUrl);
      newBannerUrl = await upload(api, bannerFile, bannerUrl);
      return api('merchant/store', { method: 'PATCH', body: {
        name: form.get('name').trim(), whatsapp: form.get('whatsapp').trim(), description: form.get('description').trim(),
        logoUrl: newLogoUrl, bannerUrl: newBannerUrl, primaryColor: form.get('primaryColor'), backgroundColor: form.get('backgroundColor'), font: form.get('font'),
        deliveryEnabled, deliveryFeeCents, paymentMethods: form.getAll('paymentMethods'),
      } });
    }, 'Personalização salva.');
    if (saved) {
      setLogoUrl(newLogoUrl);
      setBannerUrl(newBannerUrl);
      setLogoFile(null);
      setBannerFile(null);
      element.querySelectorAll('input[type="file"]').forEach((input) => { input.value = ''; });
    }
  }

  return <>
    <PageHeading title="Personalização" description="Configure a identidade da sua vitrine e as opções de pedido.">
      <a className="merchant__button" href={`/loja/${encodeURIComponent(store.slug)}`} target="_blank" rel="noopener noreferrer">Ver vitrine</a>
    </PageHeading>
    <form className="merchant__form" onSubmit={submit}>
      <fieldset disabled={pending}>
        <div className="merchant__customize-grid">
          <section className="merchant__card merchant__settings"><h2>Informações da loja</h2>
            <label className="merchant__field"><span>Nome da loja</span><input name="name" autoComplete="organization" required maxLength={100} defaultValue={store.name} /></label>
            <label className="merchant__field"><span>WhatsApp com DDD</span><input name="whatsapp" type="tel" autoComplete="tel" required defaultValue={store.whatsapp || ''} /></label>
            <label className="merchant__field"><span>Descrição</span><textarea name="description" rows={3} maxLength={500} defaultValue={store.description} /></label>
            <UploadField label="Logo da loja" url={logoUrl} onUrl={setLogoUrl} file={logoFile} onFile={setLogoFile} />
            <UploadField label="Imagem de capa" url={bannerUrl} onUrl={setBannerUrl} file={bannerFile} onFile={setBannerFile} />
          </section>
          <div className="merchant__settings-column">
            <section className="merchant__card merchant__settings"><h2>Visual da vitrine</h2>
              <div className="merchant__fields-two"><label className="merchant__field"><span>Cor principal</span><input name="primaryColor" type="color" defaultValue={store.primaryColor || '#fb650d'} /></label><label className="merchant__field"><span>Cor de fundo</span><input name="backgroundColor" type="color" defaultValue={store.backgroundColor || '#fbf7ef'} /></label></div>
              <label className="merchant__field"><span>Fonte da página</span><select name="font" defaultValue={fonts[store.font] ? store.font : 'system'}>{Object.entries(fonts).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
            </section>
            <section className="merchant__card merchant__settings"><h2>Entrega e pagamento</h2>
              <label className="merchant__check"><input type="checkbox" checked={deliveryEnabled} onChange={(event) => setDeliveryEnabled(event.target.checked)} />Oferecer tele-entrega</label>
              <label className="merchant__field"><span>Taxa de entrega (R$)</span><input name="deliveryFee" inputMode="decimal" required={deliveryEnabled} disabled={!deliveryEnabled} placeholder="0,00" defaultValue={decimal(store.deliveryFeeCents)} /><small>A taxa se aplica aos próximos pedidos.</small></label>
              <div className="merchant__payment-options"><p>Formas de pagamento aceitas</p>{Object.entries(paymentMethods).map(([value, label]) => <label className="merchant__check" key={value}><input type="checkbox" name="paymentMethods" value={value} defaultChecked={(store.paymentMethods || []).includes(value)} />{label}</label>)}</div>
            </section>
          </div>
        </div>
        {validation && <p className="merchant__error" role="alert">{validation}</p>}
        <div className="merchant__actions"><button className="merchant__button merchant__button--primary" type="submit">{pending ? 'Salvando…' : 'Salvar alterações'}</button></div>
      </fieldset>
    </form>
  </>;
}

function Subscription({ store, payments, act, pending }) {
  async function submit(event) {
    event.preventDefault();
    const element = event.currentTarget;
    const form = new FormData(element);
    const saved = await act('payment', (api) => api('merchant/payments', { method: 'POST', body: { reference: form.get('reference').trim(), receiptUrl: form.get('receiptUrl').trim() } }), 'Pagamento enviado para análise.');
    if (saved) element.reset();
  }

  return <>
    <PageHeading title="Assinatura" description="Veja a situação do seu plano e envie comprovantes para análise." />
    <div className="merchant__overview-grid">
      <section className="merchant__card merchant__overview-card"><h2>Situação do plano</h2><Badge status={store.subscriptionStatus || 'pending'} labels={subscriptionStatuses} />{store.subscriptionExpiresAt && <p>Validade {displayDate(store.subscriptionExpiresAt)}</p>}</section>
      <form className="merchant__card merchant__form" onSubmit={submit}>
        <fieldset disabled={pending}><h2>Registrar pagamento</h2>
          <label className="merchant__field"><span>Referência ou código da transação</span><input name="reference" required maxLength={180} /></label>
          <label className="merchant__field"><span>Link do comprovante (opcional)</span><input type="url" name="receiptUrl" placeholder="https://" /></label>
          <button className="merchant__button merchant__button--primary" type="submit">{pending ? 'Enviando…' : 'Enviar para análise'}</button>
        </fieldset>
      </form>
    </div>
    <section className="merchant__payment-history"><h2>Histórico de pagamentos</h2>
      {payments.length > 0 ? <ul className="merchant__product-list">{payments.map((payment) => <li className="merchant__card merchant__history-row" key={payment.id}><div><strong>{payment.reference}</strong><small>{displayDate(payment.createdAt)}</small></div><Badge status={payment.status} labels={paymentStatuses} /></li>)}</ul> : <div className="merchant__card merchant__empty"><p>Nenhum pagamento registrado.</p></div>}
    </section>
  </>;
}

function Account({ credentials, act, pending }) {
  const [error, setError] = useState('');
  const saving = pending === 'credentials';

  async function submit(event) {
    event.preventDefault();
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const email = form.get('email').trim();
    const password = form.get('password');

    if (password.length < 8 || password.length > 256) {
      setError('A senha deve ter de 8 a 256 caracteres.');
      formElement.elements.namedItem('password')?.focus();
      return;
    }
    if (password !== form.get('confirmation')) {
      setError('As senhas digitadas são diferentes.');
      formElement.elements.namedItem('confirmation')?.focus();
      return;
    }

    setError('');
    const saved = await act('credentials', (api) => api('merchant/credentials', {
      method: 'POST',
      body: { email, password },
    }), 'Acesso por e-mail e senha cadastrado.', setError);
    if (saved) formElement.reset();
  }

  return <>
    <PageHeading title="Acesso" description="Use e-mail e senha para entrar no painel desta loja." />
    {credentials ? <section className="merchant__card merchant__overview-card merchant__account">
      <h2>E-mail cadastrado</h2>
      <p className="merchant__url">{credentials.email}</p>
      <a className="merchant__button" href="/entrar">Ir para a página de login</a>
    </section> : <form className="merchant__card merchant__form merchant__account" method="post" aria-labelledby="merchant-account-title" onSubmit={submit} onInput={() => setError('')}>
      <fieldset disabled={Boolean(pending)}>
        <h2 id="merchant-account-title">Cadastrar e-mail e senha</h2>
        <label className="merchant__field"><span>E-mail</span><input name="email" type="email" autoComplete="username" autoCapitalize="none" spellCheck={false} required maxLength={254} /></label>
        <label className="merchant__field"><span>Senha</span><input name="password" type="password" autoComplete="new-password" required minLength={8} maxLength={256} aria-describedby="merchant-account-password-hint" /><small id="merchant-account-password-hint">Use de 8 a 256 caracteres.</small></label>
        <label className="merchant__field"><span>Confirme a senha</span><input name="confirmation" type="password" autoComplete="new-password" required maxLength={256} /></label>
        {error && <p className="merchant__error" role="alert">{error}</p>}
        <button className="merchant__button merchant__button--primary" type="submit">{saving ? 'Cadastrando…' : 'Cadastrar acesso'}</button>
      </fieldset>
    </form>}
  </>;
}

export default function Merchant({ store, products = [], orders = [], payments = [], credentials = null, api, onRefresh, onNavigate, tab = 'overview' }) {
  const [pending, setPending] = useState('');
  const [notice, setNotice] = useState(null);
  const busy = useRef(false);

  useEffect(() => setNotice(null), [tab]);

  async function act(key, mutation, successMessage, onError) {
    if (busy.current) return false;
    busy.current = true;
    setPending(key);
    setNotice(null);
    try {
      await mutation(api);
      try {
        await onRefresh?.();
        setNotice({ message: successMessage });
      } catch {
        setNotice({ error: true, message: 'Alteração salva. Recarregue o painel para visualizar os dados atualizados.' });
      }
      return true;
    } catch (error) {
      const message = error?.message || 'Não foi possível concluir a operação.';
      if (onError) onError(message);
      else setNotice({ error: true, message });
      return false;
    } finally {
      busy.current = false;
      setPending('');
    }
  }

  return <main className="merchant">
    {notice && <div className={`merchant__notice${notice.error ? ' merchant__notice--error' : ''}`} role={notice.error ? 'alert' : 'status'}>{notice.message}</div>}
    {!store && <Onboarding act={act} pending={pending === 'store'} />}
    {store && tab === 'overview' && <Overview store={store} products={products} orders={orders} onNavigate={onNavigate} />}
    {store && tab === 'products' && <Products products={products} act={act} pending={pending} />}
    {store && tab === 'orders' && <Orders orders={orders} act={act} pending={pending} />}
    {store && tab === 'customize' && <Customize key={store.slug} store={store} act={act} pending={pending === 'customize'} />}
    {store && tab === 'subscription' && <Subscription store={store} payments={payments} act={act} pending={pending === 'payment'} />}
    {store && tab === 'account' && <Account key={store.slug} credentials={credentials} act={act} pending={pending} />}
  </main>;
}
