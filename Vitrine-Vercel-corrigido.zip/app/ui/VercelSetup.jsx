import { AppMark, Icon } from "./Chrome.jsx";

export function VercelSetup() {
  return <>
    <header className="site-header"><div className="header-inner"><AppMark/></div></header>
    <main className="gate-card vercel-setup">
      <Icon kind="store" size={32}/>
      <h1>Vitrine em configuração</h1>
      <p>Conecte o banco Turso para liberar o cadastro de lojas e o painel.</p>
      <ol>
        <li>Abra o projeto da Vitrine no painel da Vercel.</li>
        <li>Em <strong>Settings → Environment Variables</strong>, adicione <code>TURSO_DATABASE_URL</code> e <code>TURSO_AUTH_TOKEN</code> no ambiente <strong>Production</strong>.</li>
        <li>Em <strong>Deployments</strong>, escolha <strong>Redeploy</strong>.</li>
      </ol>
      <div className="vercel-setup-actions">
        <a className="button button-primary" href="https://vercel.com/dashboard">Abrir painel da Vercel</a>
        <a className="button button-secondary" href="/loja/turbo-demo">Ver demonstração</a>
      </div>
    </main>
  </>;
}
