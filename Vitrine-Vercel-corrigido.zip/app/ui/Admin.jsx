"use client";

import { useEffect, useRef, useState } from "react";
import "./admin.css";

const STATUS = {
  active: ["Ativa", "positive"],
  blocked: ["Bloqueada", "negative"],
  pending: ["Pendente", "warning"],
  expired: ["Vencida", "negative"],
  approved: ["Aprovado", "positive"],
  rejected: ["Recusado", "negative"],
};

const DATE_FORMAT = new Intl.DateTimeFormat("pt-BR", {
  dateStyle: "short",
  timeZone: "America/Sao_Paulo",
});

const DATE_TIME_FORMAT = new Intl.DateTimeFormat("pt-BR", {
  dateStyle: "short",
  timeStyle: "short",
  timeZone: "America/Sao_Paulo",
});

function formatDate(value, includeTime = false) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "—";
  return (includeTime ? DATE_TIME_FORMAT : DATE_FORMAT).format(date);
}

function inputDate(value) {
  const date = formatDate(value);
  if (date === "—") return "";
  return date.split("/").reverse().join("-");
}

function recentFirst(rows) {
  return [...rows].sort((first, second) => new Date(second.createdAt) - new Date(first.createdAt));
}

function normalize(value) {
  return String(value ?? "").normalize("NFD").replace(/\p{Diacritic}/gu, "").toLowerCase().trim();
}

function matches(query, ...fields) {
  const normalized = normalize(query);
  return !normalized || fields.some((field) => normalize(field).includes(normalized));
}

function safeReceipt(value) {
  if (typeof value !== "string") return null;
  if (/^\/(?![\/\\])/.test(value)) return value;
  try {
    const url = new URL(value);
    return ["https:", "http:"].includes(url.protocol) ? url.href : null;
  } catch {
    return null;
  }
}

function Status({ value, label }) {
  const [defaultLabel, tone] = STATUS[value] ?? ["—", "neutral"];
  return <span className={`va-status va-${tone}`}>{label ?? defaultLabel}</span>;
}

function EmptyState({ title, detail }) {
  return (
    <div className="va-empty">
      <strong>{title}</strong>
      {detail && <p>{detail}</p>}
    </div>
  );
}

function Table({ caption, headings, children }) {
  return (
    <div className="va-table-region" tabIndex={0} role="region" aria-label={caption}>
      <table className="va-table">
        <thead>
          <tr>{headings.map((heading) => <th key={heading} scope="col">{heading}</th>)}</tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

function Header({ title, detail, children }) {
  return (
    <div className="va-heading">
      <div>
        <h1>{title}</h1>
        {detail && <p>{detail}</p>}
      </div>
      {children}
    </div>
  );
}

function Filters({ value, setValue, label, filter, setFilter, options }) {
  return (
    <div className="va-filters">
      <label className="va-search">
        <span className="va-sr-only">{label}</span>
        <input type="search" value={value} onChange={(event) => setValue(event.target.value)} placeholder={label} />
      </label>
      {options && (
        <label className="va-select-wrap">
          <span className="va-sr-only">Filtrar por status</span>
          <select value={filter} onChange={(event) => setFilter(event.target.value)}>
            {options.map(([key, name]) => <option key={key} value={key}>{name}</option>)}
          </select>
        </label>
      )}
    </div>
  );
}

function PaymentRows({ payments, review }) {
  return (
    <Table caption="Pagamentos" headings={["Loja", "Referência", "Enviado em", "Status", "Ações"]}>
      {payments.map((payment) => {
        const receipt = safeReceipt(payment.receiptUrl);
        return (
          <tr key={payment.id}>
            <th scope="row">{payment.storeName || "Loja"}</th>
            <td>{payment.reference || "—"}</td>
            <td className="va-nowrap">{formatDate(payment.createdAt)}</td>
            <td><Status value={payment.status} /></td>
            <td>
              <div className="va-actions">
                {receipt && <a className="va-button va-quiet" href={receipt} target="_blank" rel="noopener noreferrer">Comprovante</a>}
                {review && payment.status === "pending" && (
                  <>
                    <button className="va-button va-primary" type="button" onClick={() => review(payment, "approved")}>Aprovar</button>
                    <button className="va-button va-danger" type="button" onClick={() => review(payment, "rejected")}>Recusar</button>
                  </>
                )}
                {!receipt && (!review || payment.status !== "pending") && "—"}
              </div>
            </td>
          </tr>
        );
      })}
    </Table>
  );
}

function Overview({ stores, users, payments, onNavigate }) {
  const now = Date.now();
  const nextWeek = now + 7 * 24 * 60 * 60 * 1000;
  const activePlans = stores.filter((store) => store.subscriptionStatus === "active" && (
    !store.subscriptionExpiresAt || new Date(store.subscriptionExpiresAt).getTime() >= now
  ));
  const counts = [
    ["Lojas cadastradas", stores.length],
    ["Usuários", users.length],
    ["Assinaturas ativas", activePlans.length],
    ["Assinaturas pendentes", stores.filter((store) => store.subscriptionStatus === "pending").length],
    ["Pagamentos aguardando aprovação", payments.filter((payment) => payment.status === "pending").length],
    ["Planos vencidos", stores.filter((store) => store.subscriptionStatus === "expired" || (
      store.subscriptionStatus === "active" && store.subscriptionExpiresAt && new Date(store.subscriptionExpiresAt).getTime() < now
    )).length],
    ["Vencem nos próximos 7 dias", activePlans.filter((store) => store.subscriptionExpiresAt && (
      new Date(store.subscriptionExpiresAt).getTime() <= nextWeek
    )).length],
    ["Lojas bloqueadas", stores.filter((store) => store.status === "blocked").length],
  ];

  return (
    <>
      <Header title="Resumo da plataforma" />
      <dl className="va-metrics">
        {counts.map(([label, count]) => (
          <div className="va-metric" key={label}>
            <dt>{label}</dt>
            <dd>{count.toLocaleString("pt-BR")}</dd>
          </div>
        ))}
      </dl>
      <section className="va-section" aria-labelledby="va-payment-title">
        <div className="va-section-heading">
          <h2 id="va-payment-title">Histórico de pagamentos</h2>
          <button className="va-link" type="button" onClick={() => onNavigate("approvals")}>Ver todos</button>
        </div>
        {payments.length ? <PaymentRows payments={recentFirst(payments).slice(0, 5)} /> : <EmptyState title="Nenhum pagamento registrado" />}
      </section>
    </>
  );
}

function Modal({ title, children, onClose }) {
  const dialogRef = useRef(null);

  useEffect(() => {
    const dialog = dialogRef.current;
    dialog.showModal();
    return () => dialog.close();
  }, []);

  return (
    <dialog className="va-dialog" ref={dialogRef} aria-labelledby="va-dialog-title" onCancel={(event) => {
      event.preventDefault();
      onClose();
    }}>
      <h2 id="va-dialog-title">{title}</h2>
      {children}
    </dialog>
  );
}

function SubscriptionForm({ store, onSave, onClose, busy }) {
  const [status, setStatus] = useState(store.subscriptionStatus);
  const [expiration, setExpiration] = useState(inputDate(store.subscriptionExpiresAt));

  function submit(event) {
    event.preventDefault();
    const date = expiration ? new Date(`${expiration}T23:59:59.999-03:00`).toISOString() : null;
    onSave({ subscriptionStatus: status, subscriptionExpiresAt: date });
  }

  return (
    <form className="va-dialog-form" onSubmit={submit}>
      <p>{store.name}</p>
      <label className="va-field">
        <span>Status</span>
        <span className="va-select-wrap">
          <select value={status} onChange={(event) => setStatus(event.target.value)}>
            <option value="pending">Pendente</option>
            <option value="active">Ativa</option>
            <option value="expired">Vencida</option>
          </select>
        </span>
      </label>
      <label className="va-field">
        <span>Data de vencimento</span>
        <input type="date" value={expiration} onChange={(event) => setExpiration(event.target.value)} />
      </label>
      <div className="va-dialog-actions">
        <button className="va-button va-quiet" type="button" onClick={onClose} disabled={busy}>Cancelar</button>
        <button className="va-button va-primary" type="submit" disabled={busy}>{busy ? "Salvando…" : "Salvar"}</button>
      </div>
    </form>
  );
}

const PAYMENT_FILTERS = [["all", "Todos os status"], ["pending", "Pendentes"], ["approved", "Aprovados"], ["rejected", "Recusados"]];
const STORE_FILTERS = [["all", "Todos os status"], ["active", "Ativas"], ["blocked", "Bloqueadas"]];
const SUBSCRIPTION_FILTERS = [["all", "Todos os status"], ["active", "Ativas"], ["pending", "Pendentes"], ["expired", "Vencidas"]];

export default function Admin(props) {
  return <AdminPanel key={props.tab} {...props} />;
}

function AdminPanel({ data, api, onRefresh, onNavigate, tab = "overview" }) {
  const { stores = [], users = [], payments = [], history = [] } = data ?? {};
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [modal, setModal] = useState(null);
  const [notice, setNotice] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  function openModal(value) {
    setError("");
    setModal(value);
  }

  function closeModal() {
    if (!busy) setModal(null);
  }

  async function mutate(path, body, success) {
    if (busy) return;
    setError("");
    setBusy(true);
    try {
      await api(path, { method: "PATCH", body });
    } catch (failure) {
      setError(failure?.message || "A alteração não foi salva. Tente novamente.");
      setBusy(false);
      return;
    }
    setModal(null);
    setNotice(success);
    try {
      await onRefresh();
    } catch {
      setNotice(`${success} Recarregue a página para atualizar a lista.`);
    } finally {
      setBusy(false);
    }
  }

  const filteredStores = recentFirst(stores).filter((store) => (
    matches(search, store.name, store.slug, store.ownerName, store.ownerEmail)
    && (filter === "all" || (tab === "subscriptions" ? store.subscriptionStatus : store.status) === filter)
  ));
  const filteredPayments = recentFirst(payments).filter((payment) => (
    matches(search, payment.storeName, payment.reference) && (filter === "all" || payment.status === filter)
  ));
  const filteredUsers = recentFirst(users).filter((user) => matches(search, user.name, user.email));
  const filteredHistory = recentFirst(history).filter((event) => matches(search, event.description, event.actorName));
  const filterProps = { value: search, setValue: setSearch, filter, setFilter };

  let body;
  switch (tab) {
    case "approvals":
      body = (
        <>
          <Header title="Aprovação de pagamentos" detail="Consulte os comprovantes e registre sua decisão." />
          <Filters {...filterProps} label="Buscar por loja ou referência" options={PAYMENT_FILTERS} />
          {filteredPayments.length ? (
            <PaymentRows payments={filteredPayments} review={(payment, status) => openModal({ kind: "payment", payment, status })} />
          ) : (
            <EmptyState title={search || filter !== "all" ? "Nenhum pagamento encontrado" : "Nenhum pagamento registrado"} />
          )}
        </>
      );
      break;
    case "stores":
      body = (
        <>
          <Header title="Lojas" detail="Consulte as lojas cadastradas e controle a publicação das vitrines." />
          <Filters {...filterProps} label="Buscar por loja ou responsável" options={STORE_FILTERS} />
          {filteredStores.length ? (
            <Table caption="Lojas cadastradas" headings={["Loja", "Responsável", "Cadastro", "Status", "Ações"]}>
              {filteredStores.map((store) => (
                <tr key={store.id}>
                  <th scope="row">
                    {store.name}
                    {store.slug && <span className="va-subline">/loja/{store.slug}</span>}
                  </th>
                  <td>{store.ownerName || store.ownerEmail || "—"}{store.ownerName && store.ownerEmail && <span className="va-subline">{store.ownerEmail}</span>}</td>
                  <td className="va-nowrap">{formatDate(store.createdAt)}</td>
                  <td><Status value={store.status} /></td>
                  <td>
                    <div className="va-actions">
                      {store.slug && store.status !== "blocked" && <a className="va-button va-quiet" href={`/loja/${encodeURIComponent(store.slug)}`} target="_blank" rel="noopener noreferrer">Ver vitrine</a>}
                      <button className={`va-button ${store.status === "blocked" ? "va-quiet" : "va-danger"}`} type="button" onClick={() => openModal({ kind: "store", store })}>
                        {store.status === "blocked" ? "Desbloquear" : "Bloquear"}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </Table>
          ) : (
            <EmptyState title={search || filter !== "all" ? "Nenhuma loja encontrada" : "Nenhuma loja cadastrada"} detail={search || filter !== "all" ? null : "As lojas aparecem aqui assim que os lojistas concluem o cadastro."} />
          )}
        </>
      );
      break;
    case "subscriptions":
      body = (
        <>
          <Header title="Assinaturas" detail="Acompanhe a situação e o vencimento dos planos das lojas." />
          <Filters {...filterProps} label="Buscar por loja ou responsável" options={SUBSCRIPTION_FILTERS} />
          {filteredStores.length ? (
            <Table caption="Assinaturas das lojas" headings={["Loja", "Status", "Vencimento", "Ações"]}>
              {filteredStores.map((store) => (
                <tr key={store.id}>
                  <th scope="row">{store.name}</th>
                  <td><Status value={store.subscriptionStatus} /></td>
                  <td className="va-nowrap">{formatDate(store.subscriptionExpiresAt)}</td>
                  <td><button className="va-button va-quiet" type="button" onClick={() => openModal({ kind: "subscription", store })}>Editar assinatura</button></td>
                </tr>
              ))}
            </Table>
          ) : <EmptyState title={search || filter !== "all" ? "Nenhuma assinatura encontrada" : "Nenhuma assinatura cadastrada"} />}
        </>
      );
      break;
    case "users":
      body = (
        <>
          <Header title="Usuários" detail="Veja quem tem acesso à plataforma e qual é o perfil de cada conta." />
          <Filters {...filterProps} label="Buscar por nome ou e-mail" />
          {filteredUsers.length ? (
            <Table caption="Usuários da plataforma" headings={["Nome", "E-mail", "Perfil", "Cadastro"]}>
              {filteredUsers.map((user) => (
                <tr key={user.id}>
                  <th scope="row">{user.name || user.email || "Usuário"}</th>
                  <td>{user.email || "—"}</td>
                  <td><Status value={user.role === "master" ? "pending" : "neutral"} label={user.role === "master" ? "Adimin" : "Lojista"} /></td>
                  <td className="va-nowrap">{formatDate(user.createdAt)}</td>
                </tr>
              ))}
            </Table>
          ) : <EmptyState title={search ? "Nenhum usuário encontrado" : "Nenhum usuário cadastrado"} />}
        </>
      );
      break;
    case "history":
      body = (
        <>
          <Header title="Histórico" detail="Consulte as ações registradas na administração da plataforma." />
          <Filters {...filterProps} label="Buscar por ação ou responsável" />
          {filteredHistory.length ? (
            <Table caption="Histórico administrativo" headings={["Ação", "Responsável", "Data e hora"]}>
              {filteredHistory.map((event) => (
                <tr key={event.id}>
                  <th scope="row">{event.description}</th>
                  <td>{event.actorName || "—"}</td>
                  <td className="va-nowrap">{formatDate(event.createdAt, true)}</td>
                </tr>
              ))}
            </Table>
          ) : <EmptyState title={search ? "Nenhuma ação encontrada" : "Nenhuma ação registrada"} />}
        </>
      );
      break;
    default:
      body = <Overview stores={stores} users={users} payments={payments} onNavigate={onNavigate} />;
  }

  let dialog;
  if (modal?.kind === "subscription") {
    dialog = (
      <Modal title="Editar assinatura" onClose={closeModal}>
        {error && <p className="va-notice va-negative" role="alert">{error}</p>}
        <SubscriptionForm store={modal.store} onClose={closeModal} busy={busy} onSave={(changes) => mutate(
          `admin/subscriptions/${encodeURIComponent(modal.store.id)}`, changes, "Assinatura atualizada."
        )} />
      </Modal>
    );
  } else if (modal) {
    const isPayment = modal.kind === "payment";
    const isPositive = isPayment ? modal.status === "approved" : modal.store.status === "blocked";
    const action = isPayment ? (isPositive ? "Aprovar" : "Recusar") : (isPositive ? "Desbloquear" : "Bloquear");
    const title = `${action} ${isPayment ? "pagamento" : "loja"}`;
    const path = isPayment ? `admin/payments/${encodeURIComponent(modal.payment.id)}` : `admin/stores/${encodeURIComponent(modal.store.id)}`;
    const status = isPayment ? modal.status : (isPositive ? "active" : "blocked");
    const success = isPayment ? (isPositive ? "Pagamento aprovado." : "Pagamento recusado.") : (isPositive ? "Loja desbloqueada." : "Loja bloqueada.");
    dialog = (
      <Modal title={title} onClose={closeModal}>
        <p>{isPayment ? `${modal.payment.storeName || "Loja"} · Referência ${modal.payment.reference || "—"}` : modal.store.name}</p>
        {error && <p className="va-notice va-negative" role="alert">{error}</p>}
        <div className="va-dialog-actions">
          <button className="va-button va-quiet" type="button" onClick={closeModal} disabled={busy}>Cancelar</button>
          <button className={`va-button ${isPositive ? "va-primary" : "va-danger-solid"}`} type="button" onClick={() => mutate(path, { status }, success)} disabled={busy}>
            {busy ? "Salvando…" : action}
          </button>
        </div>
      </Modal>
    );
  }

  return (
    <main className="va-admin" aria-busy={busy}>
      {notice && <div className="va-notice va-positive" role="status">{notice}</div>}
      {body}
      {dialog}
    </main>
  );
}
