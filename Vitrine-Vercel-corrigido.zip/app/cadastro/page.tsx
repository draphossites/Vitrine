import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { AppMark } from "../ui/Chrome.jsx";
import MerchantAccount from "../ui/MerchantAccount.jsx";
import { VercelSetup } from "../ui/VercelSetup.jsx";
import { readMerchantSession } from "../../server/merchant-auth.mjs";
import { usesLocalCookies } from "../../server/request-auth.mjs";
import { getVitrineEnv } from "../../server/runtime.mjs";

export const dynamic = "force-dynamic";
export const metadata = { title: "Cadastro de loja | Vitrine" };

export default async function RegisterPage() {
  const { DB } = getVitrineEnv();
  if (!DB) return <VercelSetup/>;
  const requestHeaders = await headers();
  const session = await readMerchantSession(DB, requestHeaders.get("cookie"), usesLocalCookies(requestHeaders));
  if (session) redirect("/lojista");
  return <>
    <header className="site-header"><div className="header-inner"><AppMark/></div></header>
    <MerchantAccount mode="register"/>
  </>;
}
