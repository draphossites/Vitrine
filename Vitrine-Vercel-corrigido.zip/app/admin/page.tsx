import { headers } from "next/headers";
import { configuredMasterIdentity, hasMasterSession } from "../../server/master-auth.mjs";
import { usesLocalCookies } from "../../server/request-auth.mjs";
import { getVitrineEnv } from "../../server/runtime.mjs";
import { Dashboard } from "../ui/Dashboard.jsx";
import { VercelSetup } from "../ui/VercelSetup.jsx";
export const dynamic = "force-dynamic";
export const metadata = { title: "Painel Adimin | Vitrine" };
export default async function AdminPage() {
  const env = getVitrineEnv();
  if (!env.DB) return <VercelSetup/>;
  const requestHeaders = await headers();
  const master = configuredMasterIdentity(env);
  const authenticated = await hasMasterSession(requestHeaders.get("cookie"), env, master, usesLocalCookies(requestHeaders));
  return <Dashboard mode="admin" authenticated={authenticated} masterLoginAvailable={Boolean(master)}/>;
}
