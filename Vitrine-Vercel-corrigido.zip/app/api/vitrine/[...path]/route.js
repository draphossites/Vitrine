import { usesLocalCookies } from "../../../../server/request-auth.mjs";
import { getVitrineEnv } from "../../../../server/runtime.mjs";
import { handleVitrine } from "../../../../server/vitrine.mjs";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

async function respond(request, { params }) {
  const { path } = await params;
  return handleVitrine(request, path, getVitrineEnv(), usesLocalCookies(request.headers));
}
export { respond as GET, respond as POST, respond as PATCH, respond as DELETE };
