import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Vitrine | Sua loja online",
  description: "Crie seu catálogo, gerencie sua loja e receba pedidos pelo WhatsApp.",
  icons: { icon: "/vitrine.svg" },
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
