import { masterLoginConfigured } from "../server/master-auth.mjs";
import { getVitrineEnv } from "../server/runtime.mjs";
import { AppMark, Icon } from "./ui/Chrome.jsx";
import { VercelSetup } from "./ui/VercelSetup.jsx";
export const dynamic = "force-dynamic";
export default function Home() {
  const env = getVitrineEnv();
  if (!env.DB) return <VercelSetup/>;
  const adiminAvailable = masterLoginConfigured(env);
  return <>
    <header className="site-header"><div className="header-inner">
      <AppMark/>
      <nav className="site-nav" aria-label="Navegação principal">
        <a className="plain-link demo-nav" href="/loja/turbo-demo">Ver demonstração</a>
        <a href="/lojista" className="button button-primary">Painel do lojista</a>
      </nav>
    </div></header>
    <main className="home-main">
      <section className="home-hero">
        <div className="hero-copy">
          <div className="hero-topic"><Icon kind="store"/> Plataforma para lojistas</div>
          <h1>Sua loja online.<br/><span>Seus pedidos no WhatsApp.</span></h1>
          <p>Monte seu catálogo, compartilhe o link da sua loja e receba pedidos prontos com os itens e o total.</p>
          <div className="hero-actions">
            <a className="button button-primary" href="/cadastro">Criar minha loja</a>
            <a className="button button-secondary" href="/loja/turbo-demo">Ver loja de exemplo</a>
          </div>
        </div>
        <div className="hero-photo">
          <img src="/demo/turbo-banner.webp" alt="Controle sem fio e headset da loja de demonstração"/>
          <a className="photo-caption" href="/loja/turbo-demo"><span className="sample-logo">TG</span><span><strong>Turbo Games</strong><small>Loja de demonstração</small></span></a>
        </div>
      </section>
      <section className="home-features" aria-label="Recursos">
        <article><Icon kind="box"/><h2>Catálogo com link próprio</h2><p>Adicione produtos, fotos, preços e disponibilidade em um só lugar.</p></article>
        <article><Icon kind="sliders"/><h2>Do seu jeito</h2><p>Configure o visual, a entrega e as formas de pagamento da sua loja.</p></article>
        <article><Icon kind="chat"/><h2>Pedidos pelo WhatsApp</h2><p>O cliente monta a sacola e abre uma mensagem com o pedido completo.</p></article>
      </section>
    </main>
    <footer className="site-footer">
      <AppMark/><a href="/loja/turbo-demo">Catálogo de demonstração</a>
      {adiminAvailable && <a href="/admin">Adimin</a>}
    </footer>
  </>;
}
