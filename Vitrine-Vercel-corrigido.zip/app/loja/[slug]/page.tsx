import { getVitrineEnv } from "../../../server/runtime.mjs";
import { handleVitrine } from "../../../server/vitrine.mjs";
import { Catalog } from "../../ui/Catalog.jsx";
import { AppMark, Icon } from "../../ui/Chrome.jsx";
export const dynamic = "force-dynamic";
export const metadata = { title: "Catálogo de produtos | Vitrine" };
export default async function StorePage({params}: { params: Promise<{slug: string}> }) {
  const { slug } = await params;
  const response = await handleVitrine(new Request("https://vitrine.local/loja/" + encodeURIComponent(slug)), ["public",slug], getVitrineEnv());
  if (!response.ok) {
    const data = await response.json() as { error: string };
    return <><header className="site-header"><div className="header-inner"><AppMark/></div></header>
      <main className="gate-card"><Icon kind="store"/><h1>Catálogo indisponível</h1><p>{data.error}</p><a className="button button-primary" href="/">Página inicial</a></main></>;
  }
  const { store, products } = await response.json() as { store: any; products: any };
  return <Catalog store={store} products={products}/>;
}
