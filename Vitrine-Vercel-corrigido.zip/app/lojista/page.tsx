import { headers } from "next/headers";
import { readMerchantSession } from "../../server/merchant-auth.mjs";
import { usesLocalCookies } from "../../server/request-auth.mjs";
import { getVitrineEnv } from "../../server/runtime.mjs";
import { Dashboard } from "../ui/Dashboard.jsx";
import { VercelSetup } from "../ui/VercelSetup.jsx";
export const dynamic = "force-dynamic";
export const metadata = { title: "Painel do lojista | Vitrine" };
export default async function MerchantPage({ searchParams }: { searchParams: Promise<{ aba?: string }> }) {
  const { DB } = getVitrineEnv();
  if (!DB) return <VercelSetup/>;
  const [requestHeaders, query] = await Promise.all([headers(), searchParams]);
  const session = await readMerchantSession(DB, requestHeaders.get("cookie"), usesLocalCookies(requestHeaders));
  return <Dashboard mode="merchant" authenticated={Boolean(session)} initialTab={query?.aba === "acesso" ? "account" : "overview"}/>;
}
