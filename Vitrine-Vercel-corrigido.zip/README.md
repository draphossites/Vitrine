# Vitrine na Vercel

A Vitrine é um app Next.js para criar catálogos online e receber pedidos pelo WhatsApp. O banco de produção começa vazio. A loja de exemplo **Turbo Games** já vem no código, em `/loja/turbo-demo`. As contas, lojas, imagens enviadas e credenciais do Sites ficam na instalação original.

## 1. Publique o ZIP pelo Vercel Drop

1. Arraste o ZIP atualizado para o Vercel Drop. Escolha sua conta ou equipe, dê um nome ao projeto e clique em **Deploy**. [Abrir o Vercel Drop](https://vercel.com/drop)
2. Quando o deploy ficar **Ready**, abra o endereço de produção. A página inicial e a demonstração em `/loja/turbo-demo` já funcionam durante a configuração. Continue com os passos seguintes para liberar o cadastro, os painéis e o envio de imagens.

Cada envio pelo Drop cria um projeto. Se o deploy do ZIP anterior falhou porque faltavam `TURSO_DATABASE_URL` e `TURSO_AUTH_TOKEN`, você pode recuperar o projeto existente. Abra-o no painel da Vercel, adicione as duas variáveis de **Production** conforme o passo 2 e clique em **Redeploy** conforme o passo 5. O redeploy usa os arquivos que você já enviou. [Como funciona o Vercel Drop](https://vercel.com/changelog/vercel-drop), [como refazer um deploy](https://vercel.com/docs/deployments/managing-deployments#redeploy-a-project)

## 2. Conecte o banco Turso

No projeto da Vercel, abra **Storage → Create Database → Turso**. Crie ou conecte um banco ao ambiente **Production**. A integração adiciona `TURSO_DATABASE_URL` e `TURSO_AUTH_TOKEN` ao projeto. [Turso no Vercel Marketplace](https://vercel.com/marketplace/tursocloud/database)

Se preferir configurar o banco manualmente, crie um banco **libSQL** no Turso, copie a URL de conexão e gere um token com acesso de escrita. Você também pode obter esses valores com a CLI do Turso. Substitua `vitrine` pelo nome do banco que você escolher. [Painel do Turso](https://app.turso.tech/), [guia da CLI](https://docs.turso.tech/quickstart)

```bash
turso auth login
turso db create vitrine
turso db show --url vitrine
turso db tokens create vitrine
```

No projeto da Vercel, abra **Settings → Environment Variables**. Na configuração manual, adicione `TURSO_DATABASE_URL` com a URL do banco e `TURSO_AUTH_TOKEN` com o token. Selecione **Production** e salve o token como **Secret**. [Configurações do projeto](https://vercel.com/docs/project-configuration/project-settings), [como adicionar variáveis de ambiente](https://vercel.com/docs/environment-variables/managing-environment-variables)

## 3. Configure o acesso do Adimin

Instale o Node.js **24.x**, extraia uma cópia do ZIP no computador e abra um terminal na pasta que contém `package.json`. Execute o comando abaixo. [Download do Node.js](https://nodejs.org/en/download)

```bash
node scripts/configurar-adimin.mjs
```

Digite o e-mail e escolha a senha que você vai usar em `/admin`. A senha fica oculta enquanto você digita. O comando grava em `.env.local` o e-mail, um verificador da senha e uma chave de sessão. Guarde a senha para entrar no painel e mantenha o arquivo `.env.local` no seu computador.

Abra `.env.local` em um editor. Em **Settings → Environment Variables** do projeto na Vercel, adicione as três variáveis abaixo como **Secret** em **Production**. Para cada variável, copie o trecho depois do `=`. [Variáveis Secret na Vercel](https://vercel.com/docs/environment-variables/sensitive-environment-variables)

| Nome | Valor |
| --- | --- |
| `VITRINE_MASTER_LOGIN_EMAIL` | E-mail gravado em `.env.local` |
| `VITRINE_MASTER_PASSWORD_VERIFIER` | Valor que começa com `v1:` |
| `VITRINE_MASTER_SESSION_KEY` | Chave de sessão gravada em `.env.local` |

## 4. Ative o envio de imagens

No projeto da Vercel, abra **Storage → Create Database → Blob**. Escolha **Public** como tipo de acesso e conecte o armazenamento ao ambiente **Production**. A integração atual usa OIDC para autenticar os uploads automaticamente. Em uma conexão legada, a Vercel fornece `BLOB_READ_WRITE_TOKEN`. [Como criar um Blob público](https://vercel.com/docs/vercel-blob/public-storage), [autenticação OIDC do Vercel Blob](https://vercel.com/changelog/vercel-blob-now-supports-oidc-authentication)

## 5. Aplique as configurações com Redeploy

No mesmo projeto, abra **Deployments**, procure a publicação mais recente de **Production** e clique em **⋯ → Redeploy**. Confirme e aguarde até aparecer **Ready**. É nesse novo deploy que as variáveis e a conexão com o Blob entram em vigor. Com o Turso configurado, o build cria as tabelas do banco e, nos próximos deploys, aplica as migrações pendentes. [Como refazer um deploy](https://vercel.com/docs/deployments/managing-deployments#redeploy-a-project)

## 6. Confira o site publicado

Abra o domínio de produção exibido pela Vercel. Acrescente cada caminho abaixo ao endereço.

| Caminho | O que você pode fazer |
| --- | --- |
| `/` | Abrir a página inicial |
| `/loja/turbo-demo` | Ver um catálogo pronto com os dados de demonstração |
| `/cadastro` | Criar uma conta de lojista e uma loja |
| `/entrar` | Entrar como lojista |
| `/lojista` | Configurar a loja, adicionar produtos e enviar uma foto |
| `/admin` | Entrar no Adimin com o e-mail e a senha definidos no passo 3 |

Compartilhe o endereço `/loja/<slug-da-loja>` que aparece no painel do lojista para que os clientes vejam o seu catálogo.

## Publicar pelo GitHub

Se quiser publicar a partir do GitHub, extraia o ZIP e envie o conteúdo para um repositório. Mantenha `package.json`, `vercel.json`, `.gitignore` e `.env.example` na raiz. Guarde o `.env.local` no seu computador. Na Vercel, escolha **Add New → Project**, importe o repositório e selecione **Next.js**. Depois do primeiro deploy, siga os passos 2 a 6 neste guia. [Como enviar arquivos ao GitHub](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository), [como importar um repositório na Vercel](https://vercel.com/docs/git)

## Rodar no computador

Na pasta extraída, com Node.js 24.x, execute estes comandos. Gere o acesso do Adimin conforme o passo 3 se quiser testar esse painel.

```bash
npm ci
npm run db:migrate
npm run dev
```

Abra [http://localhost:3000](http://localhost:3000). Em desenvolvimento, a configuração padrão usa SQLite e imagens locais em `.vitrine-data/`. Se quiser usar um banco Turso de desenvolvimento, adicione as duas variáveis do Turso em `.env.local` e rode `npm run db:migrate` novamente. Para testar imagens com um Blob público fora da Vercel, você pode adicionar `BLOB_READ_WRITE_TOKEN` do armazenamento ao mesmo arquivo. [.env.example](.env.example)
