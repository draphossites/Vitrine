import { requestClientIp } from "./request-auth.mjs";

const encoder = new TextEncoder();
const passwordIterations = 100_000;
const sessionLifetimeSeconds = 7 * 24 * 60 * 60;
const loginWindowSeconds = 15 * 60;
const loginAttemptsPerWindow = 10;

const nowInSeconds = () => Math.floor(Date.now() / 1000);
const cookieName = (localPreview) => localPreview ? "vitrine_merchant" : "__Host-vitrine_merchant";
const fromHex = (hex) => Uint8Array.from(hex.match(/../g), (pair) => Number.parseInt(pair, 16));
const asHex = (bytes) => Array.from(new Uint8Array(bytes), (byte) => byte.toString(16).padStart(2, "0")).join("");

export function normalizeMerchantEmail(value) {
  if (typeof value !== "string") return null;
  const email = value.trim().toLowerCase();
  if (email.length > 254) return null;
  const parts = email.split("@");
  if (parts.length !== 2) return null;
  const [local, domain] = parts;
  if (local.length > 64 || !/^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+$/.test(local)) return null;
  if (local.startsWith(".") || local.endsWith(".") || local.includes("..")) return null;
  const labels = domain.split(".");
  if (labels.length < 2 || !labels.every((label) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label))) return null;
  return email;
}

export function validMerchantPassword(password) {
  return typeof password === "string" && password.length >= 8 && password.length <= 256;
}

async function derivePassword(password, salt) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  return new Uint8Array(await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", iterations: passwordIterations, salt }, key, 256,
  ));
}

export async function hashMerchantPassword(password) {
  if (!validMerchantPassword(password)) throw new TypeError("Invalid merchant password");
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const hash = await derivePassword(password, salt);
  return `v1:${asHex(salt)}:${asHex(hash)}`;
}

export async function verifyMerchantPassword(password, verifier) {
  if (!validMerchantPassword(password)) return false;
  const parts = typeof verifier === "string" ? /^v1:([0-9a-f]{32}):([0-9a-f]{64})$/.exec(verifier) : null;
  const salt = parts ? fromHex(parts[1]) : new Uint8Array(16);
  const expected = parts ? fromHex(parts[2]) : new Uint8Array(32);
  const actual = await derivePassword(password, salt);
  let differences = 0;
  for (let index = 0; index < expected.length; index += 1) differences |= expected[index] ^ actual[index];
  return parts !== null && differences === 0;
}

async function sha256Hex(bytes) {
  return asHex(await crypto.subtle.digest("SHA-256", bytes));
}

function merchantCookie(value, maxAge, localPreview) {
  return [`${cookieName(localPreview)}=${value}`, "Path=/", `Max-Age=${maxAge}`, "HttpOnly", "SameSite=Lax",
    ...(localPreview ? [] : ["Secure"])].join("; ");
}

async function cookieTokenHash(cookieHeader, localPreview) {
  if (!cookieHeader) return null;
  const prefix = `${cookieName(localPreview)}=`;
  for (const entry of cookieHeader.split(";")) {
    const cookie = entry.trim();
    if (!cookie.startsWith(prefix)) continue;
    const value = cookie.slice(prefix.length);
    return /^[0-9a-f]{64}$/.test(value) ? sha256Hex(fromHex(value)) : null;
  }
  return null;
}

export async function createMerchantSession(userId, localPreview) {
  const token = crypto.getRandomValues(new Uint8Array(32));
  const createdAt = nowInSeconds();
  return {
    tokenHash: await sha256Hex(token),
    userId,
    expiresAt: createdAt + sessionLifetimeSeconds,
    createdAt,
    cookie: merchantCookie(asHex(token), sessionLifetimeSeconds, localPreview),
  };
}

export async function readMerchantSession(db, cookieHeader, localPreview) {
  if (!db) return null;
  const tokenHash = await cookieTokenHash(cookieHeader, localPreview);
  if (!tokenHash) return null;
  return db.prepare(`
    SELECT users.id AS userId, users.name AS displayName, merchant_credentials.email AS email
    FROM merchant_sessions
    JOIN users ON users.id = merchant_sessions.user_id
    JOIN merchant_credentials ON merchant_credentials.user_id = users.id
    WHERE merchant_sessions.token_hash = ? AND merchant_sessions.expires_at > ?
  `).bind(tokenHash, nowInSeconds()).first();
}

export async function revokeMerchantSession(db, cookieHeader, localPreview) {
  const tokenHash = db ? await cookieTokenHash(cookieHeader, localPreview) : null;
  if (tokenHash) {
    await db.prepare("DELETE FROM merchant_sessions WHERE token_hash = ?").bind(tokenHash).run();
  }
  return merchantCookie("", 0, localPreview);
}

async function loginAttemptKey(email, request) {
  return sha256Hex(encoder.encode(JSON.stringify([email, requestClientIp(request) ?? ""])));
}

export async function allowMerchantLoginAttempt(db, email, request) {
  const key = await loginAttemptKey(email, request);
  const now = nowInSeconds();
  const cutoff = now - loginWindowSeconds;
  const attempt = await db.prepare(`
    INSERT INTO merchant_login_attempts (key, starts_at, attempts) VALUES (?, ?, 1)
    ON CONFLICT (key) DO UPDATE SET
      starts_at = CASE WHEN merchant_login_attempts.starts_at <= ? THEN excluded.starts_at ELSE merchant_login_attempts.starts_at END,
      attempts = CASE WHEN merchant_login_attempts.starts_at <= ? THEN 1 ELSE merchant_login_attempts.attempts + 1 END
    WHERE merchant_login_attempts.starts_at <= ? OR merchant_login_attempts.attempts < ?
    RETURNING attempts
  `).bind(key, now, cutoff, cutoff, cutoff, loginAttemptsPerWindow).first();
  return Boolean(attempt);
}

export async function clearMerchantLoginAttempts(db, email, request) {
  const key = await loginAttemptKey(email, request);
  await db.prepare("DELETE FROM merchant_login_attempts WHERE key = ?").bind(key).run();
}
