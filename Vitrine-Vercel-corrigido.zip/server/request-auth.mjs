import { isVercel } from "./database.mjs";

const loopbackHost = /^(?:localhost|127\.0\.0\.1|\[::1\])(?::\d{1,5})?$/i;
const requestHost = /^(?:[a-z0-9.-]+|\[[a-f0-9:.]+\])(?::\d{1,5})?$/i;

export function usesLocalCookies(headers) {
  return !isVercel() &&
    headers.get("x-forwarded-proto") !== "https" &&
    loopbackHost.test(headers.get("host") ?? "");
}

export function requestOrigin(request) {
  const url = new URL(request.url);
  const hosted = isVercel();
  const forwardedHost = hosted && request.headers.get("x-forwarded-host");
  const host = forwardedHost || request.headers.get("host");
  if (!host) return url.origin;
  if (!requestHost.test(host)) return null;

  const protocol = hosted ? "https:" : url.protocol;
  try {
    return new URL(`${protocol}//${host}`).origin;
  } catch {
    return null;
  }
}

export function requestClientIp(request) {
  return isVercel() ? request.headers.get("x-vercel-forwarded-for") : null;
}
