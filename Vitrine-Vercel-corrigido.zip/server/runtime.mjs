import { randomUUID } from "node:crypto";
import { mkdir, open, rename, rm, writeFile } from "node:fs/promises";
import { extname, join } from "node:path";
import { Readable } from "node:stream";
import { put } from "@vercel/blob";
import { createVitrineClient, isVercel, localDataDirectory, needsHostedDatabaseSetup, vitrineDatabase } from "./database.mjs";

const localMediaDirectory = join(localDataDirectory, "media");
const contentTypes = {
  ".png": "image/png", ".jpg": "image/jpeg", ".webp": "image/webp", ".avif": "image/avif",
};

function localMediaPath(key) {
  if (!/^[a-f0-9-]+\.(?:png|jpg|webp|avif)$/.test(key)) {
    throw new Error("Chave de imagem inválida.");
  }
  return join(localMediaDirectory, key);
}

const localBucket = {
  async put(key, body) {
    const file = localMediaPath(key);
    const temporary = `${file}.${randomUUID()}.tmp`;
    await mkdir(localMediaDirectory, { recursive: true });
    try {
      await writeFile(temporary, body, { flag: "wx" });
      await rename(temporary, file);
    } finally {
      await rm(temporary, { force: true });
    }
    return { url: `/api/vitrine/media/${key}` };
  },

  async get(key) {
    const file = await open(localMediaPath(key), "r").catch((error) => {
      if (error.code === "ENOENT") return null;
      throw error;
    });
    if (!file) return null;
    return {
      body: Readable.toWeb(file.createReadStream()),
      writeHttpMetadata(headers) {
        headers.set("Content-Type", contentTypes[extname(key)]);
      },
    };
  },
};

function vitrineBucket() {
  if (process.env.BLOB_STORE_ID?.trim() || process.env.BLOB_READ_WRITE_TOKEN?.trim()) {
    return {
      async put(key, body, { httpMetadata }) {
        // Keep the upload body reusable for SDK retries.
        const image = await new Response(body).blob();
        return put(key, image, {
          access: "public", contentType: httpMetadata.contentType, allowOverwrite: true,
        });
      },
      async get() {
        return null;
      },
    };
  }
  return isVercel() ? null : localBucket;
}

let db;

export function getVitrineEnv() {
  const database = needsHostedDatabaseSetup() ? null : (db ??= vitrineDatabase(createVitrineClient()));
  return {
    DB: database,
    BUCKET: vitrineBucket(),
    VITRINE_MASTER_LOGIN_EMAIL: process.env.VITRINE_MASTER_LOGIN_EMAIL,
    VITRINE_MASTER_PASSWORD_VERIFIER: process.env.VITRINE_MASTER_PASSWORD_VERIFIER,
    VITRINE_MASTER_SESSION_KEY: process.env.VITRINE_MASTER_SESSION_KEY,
  };
}
