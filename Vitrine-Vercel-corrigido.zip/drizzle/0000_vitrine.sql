CREATE TABLE `history` (
	`id` text PRIMARY KEY NOT NULL,
	`actor_name` text NOT NULL,
	`description` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `history_date_idx` ON `history` (`created_at`);--> statement-breakpoint
CREATE TABLE `orders` (
	`id` text PRIMARY KEY NOT NULL,
	`store_id` text NOT NULL,
	`request_id` text NOT NULL,
	`customer_name` text NOT NULL,
	`fulfillment` text NOT NULL,
	`address` text NOT NULL,
	`payment_method` text NOT NULL,
	`notes` text NOT NULL,
	`items` text NOT NULL,
	`total_cents` integer NOT NULL,
	`delivery_fee_cents` integer NOT NULL,
	`status` text DEFAULT 'open' NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`store_id`) REFERENCES `stores`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `orders_request_idx` ON `orders` (`store_id`,`request_id`);--> statement-breakpoint
CREATE INDEX `orders_store_idx` ON `orders` (`store_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `payments` (
	`id` text PRIMARY KEY NOT NULL,
	`store_id` text NOT NULL,
	`reference` text NOT NULL,
	`receipt_url` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`review_key` text,
	`created_at` text NOT NULL,
	FOREIGN KEY (`store_id`) REFERENCES `stores`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `payments_store_idx` ON `payments` (`store_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `products` (
	`id` text PRIMARY KEY NOT NULL,
	`store_id` text NOT NULL,
	`name` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`price_cents` integer NOT NULL,
	`image_url` text DEFAULT '' NOT NULL,
	`category` text DEFAULT '' NOT NULL,
	`available` integer DEFAULT 1 NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`store_id`) REFERENCES `stores`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `products_store_idx` ON `products` (`store_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `stores` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`slug` text NOT NULL,
	`name` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`whatsapp` text NOT NULL,
	`logo_url` text DEFAULT '' NOT NULL,
	`banner_url` text DEFAULT '' NOT NULL,
	`primary_color` text DEFAULT '#fb650d' NOT NULL,
	`background_color` text DEFAULT '#fbf7ef' NOT NULL,
	`font` text DEFAULT 'system' NOT NULL,
	`delivery_enabled` integer DEFAULT 0 NOT NULL,
	`delivery_fee_cents` integer DEFAULT 0 NOT NULL,
	`payment_methods` text DEFAULT '["pix","card","cash"]' NOT NULL,
	`status` text DEFAULT 'active' NOT NULL,
	`subscription_status` text DEFAULT 'pending' NOT NULL,
	`subscription_expires_at` text,
	`created_at` text NOT NULL,
	FOREIGN KEY (`owner_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `stores_owner_id_unique` ON `stores` (`owner_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `stores_slug_unique` ON `stores` (`slug`);--> statement-breakpoint
CREATE TABLE `users` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`email` text NOT NULL,
	`created_at` text NOT NULL
);
