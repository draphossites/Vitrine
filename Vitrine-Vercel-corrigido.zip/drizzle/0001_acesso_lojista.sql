CREATE TABLE `merchant_credentials` (
	`user_id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`verifier` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `merchant_credentials_email_unique` ON `merchant_credentials` (`email`);--> statement-breakpoint
CREATE TABLE `merchant_login_attempts` (
	`key` text PRIMARY KEY NOT NULL,
	`starts_at` integer NOT NULL,
	`attempts` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `merchant_login_attempts_starts_idx` ON `merchant_login_attempts` (`starts_at`);--> statement-breakpoint
CREATE TABLE `merchant_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`expires_at` integer NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `merchant_sessions_expires_idx` ON `merchant_sessions` (`expires_at`);--> statement-breakpoint
CREATE INDEX `merchant_sessions_user_idx` ON `merchant_sessions` (`user_id`);